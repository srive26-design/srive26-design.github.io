// utils.cpp - implementation file for utility functions
#include "utils.h"

#include <algorithm> // find_if
#include <cctype>    // toupper, isspace
#include <chrono>    // milliseconds
#include <cstdlib>   // system
#include <iostream>  // cin, cout
#include <sstream>   // stringstream
#include <thread>    // this_thread

#ifdef _WIN32
#include <windows.h> // Windows console color and Beep functions
#endif

// removes spaces from the beginning and end of user input
static std::string trimInput(const std::string &text)
{
    std::string result = text;

    result.erase(
        result.begin(),
        std::find_if(
            result.begin(),
            result.end(),
            [](unsigned char ch)
            {
                return !std::isspace(ch);
            }));

    result.erase(
        std::find_if(
            result.rbegin(),
            result.rend(),
            [](unsigned char ch)
            {
                return !std::isspace(ch);
            })
            .base(),
        result.end());

    return result;
}

void waitForKey()
{
    std::cout << "\nPress Enter to continue...";

    std::string input;

    std::getline(std::cin, input);
}

void delay(int ms)
{
    std::this_thread::sleep_for(std::chrono::milliseconds(ms));
}

void clearScreen()
{
#ifdef _WIN32

    system("cls");

#else

    std::cout << "\033[2J\033[H" << std::flush;

#endif
}

void setTextColor(ConsoleColor color)
{
#ifdef _WIN32

    HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);

    WORD attributes =
        FOREGROUND_RED |
        FOREGROUND_GREEN |
        FOREGROUND_BLUE;

    switch (color)
    {
    case COLOR_RED:
        attributes = FOREGROUND_RED | FOREGROUND_INTENSITY;
        break;

    case COLOR_GREEN:
        attributes = FOREGROUND_GREEN | FOREGROUND_INTENSITY;
        break;

    case COLOR_YELLOW:
        attributes =
            FOREGROUND_RED |
            FOREGROUND_GREEN |
            FOREGROUND_INTENSITY;
        break;

    case COLOR_BLUE:
        attributes =
            FOREGROUND_BLUE |
            FOREGROUND_INTENSITY;
        break;

    case COLOR_MAGENTA:
        attributes =
            FOREGROUND_RED |
            FOREGROUND_BLUE |
            FOREGROUND_INTENSITY;
        break;

    case COLOR_CYAN:
        attributes =
            FOREGROUND_GREEN |
            FOREGROUND_BLUE |
            FOREGROUND_INTENSITY;
        break;

    case COLOR_WHITE:
        attributes =
            FOREGROUND_RED |
            FOREGROUND_GREEN |
            FOREGROUND_BLUE |
            FOREGROUND_INTENSITY;
        break;

    case COLOR_GRAY:
        attributes = FOREGROUND_INTENSITY;
        break;

    case COLOR_DEFAULT:
    default:
        attributes =
            FOREGROUND_RED |
            FOREGROUND_GREEN |
            FOREGROUND_BLUE;
        break;
    }

    SetConsoleTextAttribute(console, attributes);

#else

    const char *code = "\033[0m";

    switch (color)
    {
    case COLOR_RED:
        code = "\033[91m";
        break;

    case COLOR_GREEN:
        code = "\033[92m";
        break;

    case COLOR_YELLOW:
        code = "\033[93m";
        break;

    case COLOR_BLUE:
        code = "\033[94m";
        break;

    case COLOR_MAGENTA:
        code = "\033[95m";
        break;

    case COLOR_CYAN:
        code = "\033[96m";
        break;

    case COLOR_WHITE:
        code = "\033[97m";
        break;

    case COLOR_GRAY:
        code = "\033[90m";
        break;

    case COLOR_DEFAULT:
    default:
        code = "\033[0m";
        break;
    }

    std::cout << code;

#endif
}

void resetTextColor()
{
    setTextColor(COLOR_DEFAULT);
}

void playSoundEffect(SoundEffect effect)
{
#ifdef _WIN32

    // Beep is kept short so sound adds feedback without slowing down gameplay
    switch (effect)
    {
    case SOUND_MENU:
        Beep(650, 50);
        break;

    case SOUND_PICKUP:
        Beep(850, 70);
        Beep(1050, 70);
        break;

    case SOUND_ALERT:
        Beep(350, 120);
        Beep(280, 160);
        break;

    case SOUND_HIT:
        Beep(220, 180);
        break;

    case SOUND_SUCCESS:
        Beep(700, 80);
        Beep(900, 80);
        Beep(1150, 100);
        break;

    case SOUND_CRASH:
        Beep(180, 200);
        Beep(120, 260);
        break;
    }

#else

    (void)effect;

    // terminal bell fallback for non-Windows systems
    std::cout << '\a' << std::flush;

#endif
}

void displayHeader(const std::string &title, int width)
{
    if (width < static_cast<int>(title.length()) + 2)
        width = static_cast<int>(title.length()) + 2;

    int leftPadding =
        (width - static_cast<int>(title.length())) / 2;

    std::cout << std::string(width, '=') << "\n";

    std::cout << std::string(leftPadding, ' ')
              << title
              << "\n";

    std::cout << std::string(width, '=') << "\n";
}

int getIntInRange(int min, int max)
{
    while (true)
    {
        std::string line;

        std::getline(std::cin, line);

        line = trimInput(line);

        std::stringstream input(line);

        int value;

        char extra;

        // valid input contains one integer and nothing else
        if ((input >> value) &&
            !(input >> extra) &&
            value >= min &&
            value <= max)
        {
            return value;
        }

        std::cout << "Invalid choice. Try again ("
                  << min
                  << "-"
                  << max
                  << "): ";
    }
}

char getCharChoice(const std::string &validOptions)
{
    while (true)
    {
        std::string line;

        std::getline(std::cin, line);

        line = trimInput(line);

        if (line.length() == 1)
        {
            char choice =
                static_cast<char>(
                    std::toupper(
                        static_cast<unsigned char>(line[0])));

            if (validOptions.find(choice) != std::string::npos)
                return choice;
        }

        std::cout << "Invalid input. Valid options: "
                  << validOptions
                  << "\nTry again: ";
    }
}

std::string getLineInput(const std::string &prompt,
                         int minLen,
                         int maxLen)
{
    while (true)
    {
        std::cout << prompt;

        std::string input;

        std::getline(std::cin, input);

        input = trimInput(input);

        int length = static_cast<int>(input.length());

        if (length >= minLen && length <= maxLen)
            return input;

        std::cout << "Please enter between "
                  << minLen
                  << " and "
                  << maxLen
                  << " characters.\n";
    }
}