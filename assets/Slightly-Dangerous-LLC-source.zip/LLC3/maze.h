// maze.h - header file for the Maze class
#ifndef MAZE_H
#define MAZE_H

#include "item.h"
#include "monster.h"
#include "room.h"

#include <string>
#include <vector>

class Maze
{
private:
    int rows;
    int cols;
    int dayTheme; // day used to generate the current room types and atmosphere

    std::vector<std::vector<Room>> grid;

    // recursive backtracking helper used to carve the maze
    void generateRecursive(int r, int c);

    // Step 2 helpers used after the maze's passages have been carved
    void assignRoomTypes(int currentDay);
    void placeExit(int startR, int startC);

    RoomType chooseRoomType(int currentDay) const;
    int getItemSpawnModifier(RoomType type) const;
    int getMonsterSpawnModifier(RoomType type) const;

    bool hasVisitedNeighbor(int r, int c) const;

    std::string getRoomTypeName(RoomType type) const;
    std::string getRoomFlavor(RoomType type, int currentDay) const;

public:
    Maze(int r = 5, int c = 5);

    ~Maze(); // cleans up dynamically allocated items and monsters

    int getRows() const;
    int getCols() const;

    Room &getRoom(int r, int c);
    const Room &getRoom(int r, int c) const;

    void generateMaze(int currentDay);

    void displayRoom(int r, int c, bool firstVisit) const;

    // displays only explored rooms and doors discovered from those rooms
    void displayMap(int playerRow, int playerCol) const;

    Item *generateRandomItem(int currentDay, RoomType roomType);

    Monster *generateRandomMonster(int currentDay);
};

#endif
