// hud.h - screen display functions
#ifndef HUD_H
#define HUD_H

#include "item.h"
#include "player.h"

#include <string>

void displayHUD(
    const Player &player,
    int day,
    int quota,
    const std::string &shiftName);

void displayItemDiscovery(
    const Item &item);

void displayInventoryScreen(
    const Player &player);

void displayLoreJournal(
    const Player &player);

void displayTurnInReceipt(
    const Player &player);

void displayMonsterEncounter(
    const std::string &name,
    const std::string &desc);

void displayDayComplete(
    int day,
    const Player &player);

void displayGameWon(
    const Player &player);

void displayGameOver(
    const Player &player);

void displayMonsterDefeated(
    const std::string &name);

void displayMonsterHit(
    const std::string &name,
    int heartsLeft);

int displayMenu();

void displayRules();

#endif
