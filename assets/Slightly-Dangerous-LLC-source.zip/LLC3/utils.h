// utils.h - utility functions used by multiple files
#ifndef UTILS_H
#define UTILS_H

#include <string>

// available console colors used throughout the game
enum ConsoleColor
{
    COLOR_DEFAULT,
    COLOR_RED,
    COLOR_GREEN,
    COLOR_YELLOW,
    COLOR_BLUE,
    COLOR_MAGENTA,
    COLOR_CYAN,
    COLOR_WHITE,
    COLOR_GRAY
};

// basic sound effects so individual files do not need platform-specific sound code
enum SoundEffect
{
    SOUND_MENU,
    SOUND_PICKUP,
    SOUND_ALERT,
    SOUND_HIT,
    SOUND_SUCCESS,
    SOUND_CRASH
};

void waitForKey(); // waits for Enter before continuing

void delay(int ms); // delays execution for the given number of milliseconds

void clearScreen(); // clears the console screen

void setTextColor(ConsoleColor color); // changes console text color

void resetTextColor(); // resets console text to its default color

void playSoundEffect(SoundEffect effect); // plays a small sound effect

void displayHeader(const std::string &title, int width = 40); // displays a centered heading

int getIntInRange(int min, int max); // gets an integer within a range

char getCharChoice(const std::string &validOptions); // gets one valid character

std::string getLineInput(const std::string &prompt,
                         int minLen,
                         int maxLen); // gets a line of text within a length range

#endif