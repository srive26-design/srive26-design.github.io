// maze.cpp - maze generation, room rendering, and discovered map system
#include "maze.h"

#include <algorithm> // swap
#include <cstdlib>   // rand
#include <iostream>  // cout
#include <queue>     // queue used to find the farthest room
#include <string>
#include <utility> // pair
#include <vector>

// Places text inside a room canvas without writing outside its edges.
static void placeText(
    std::vector<std::string> &canvas,
    int row,
    int col,
    const std::string &text)
{
    if (row < 0 || row >= static_cast<int>(canvas.size()))
        return;

    for (int i = 0; i < static_cast<int>(text.length()); i++)
    {
        int targetCol = col + i;

        if (targetCol > 0 &&
            targetCol < static_cast<int>(canvas[row].length()) - 1)
        {
            canvas[row][targetCol] = text[i];
        }
    }
}

// Places a small multi-line ASCII drawing inside the room canvas.
static void placeArt(
    std::vector<std::string> &canvas,
    int row,
    int col,
    const std::vector<std::string> &art)
{
    for (int line = 0; line < static_cast<int>(art.size()); line++)
        placeText(canvas, row + line, col, art[line]);
}

Maze::Maze(int r, int c)
{
    rows = r;
    cols = c;
    dayTheme = 1;

    grid.resize(rows, std::vector<Room>(cols));
}

Maze::~Maze()
{
    // Maze owns the item and monster pointers stored inside each room.
    for (int r = 0; r < rows; r++)
    {
        for (int c = 0; c < cols; c++)
        {
            Room &room = grid[r][c];

            if (room.getItem())
            {
                delete room.getItem();
                room.setItem(nullptr);
            }

            if (room.getMonster())
            {
                delete room.getMonster();
                room.setMonster(nullptr);
            }
        }
    }
}

int Maze::getRows() const
{
    return rows;
}

int Maze::getCols() const
{
    return cols;
}

Room &Maze::getRoom(int r, int c)
{
    return grid[r][c];
}

const Room &Maze::getRoom(int r, int c) const
{
    return grid[r][c];
}

Item *Maze::generateRandomItem(
    int currentDay,
    RoomType roomType)
{
    const ItemInfo *pool = nullptr;
    int poolSize = 0;
    int roll = std::rand() % 100;

    // Story clues are uncommon but become more likely in rooms connected
    // to research, records, or the original facility.
    int storyChance = 10 + (currentDay * 4);

    if (roomType == ROOM_OFFICE ||
        roomType == ROOM_LABORATORY ||
        roomType == ROOM_TESTING ||
        roomType == ROOM_RITUAL_CHAMBER)
    {
        storyChance += 10;
    }

    if (roll < storyChance)
    {
        if (currentDay == 1)
        {
            pool = DAY1_STORY_ITEMS;
            poolSize = DAY1_STORY_ITEM_COUNT;
        }
        else if (currentDay == 2)
        {
            pool = DAY2_STORY_ITEMS;
            poolSize = DAY2_STORY_ITEM_COUNT;
        }
        else
        {
            pool = DAY3_STORY_ITEMS;
            poolSize = DAY3_STORY_ITEM_COUNT;
        }
    }
    else if (currentDay == 1)
    {
        // Day 1 still resembles a human workplace. Maintenance and waste
        // rooms occasionally contain belongings from older maze candidates.
        bool oldMazeLoot =
            (roomType == ROOM_MAINTENANCE ||
             roomType == ROOM_WASTE_PROCESSING) &&
            (std::rand() % 100 < 30);

        if (oldMazeLoot)
        {
            pool = OLD_MAZE_ITEMS;
            poolSize = OLD_MAZE_ITEM_COUNT;
        }
        else
        {
            pool = NORMAL_ITEMS;
            poolSize = NORMAL_ITEM_COUNT;
        }
    }
    else if (currentDay == 2)
    {
        int categoryRoll = std::rand() % 100;

        if (roomType == ROOM_FUNGUS_GROWTH ||
            roomType == ROOM_WASTE_PROCESSING)
        {
            if (categoryRoll < 65)
            {
                pool = CREATURE_ITEMS;
                poolSize = CREATURE_ITEM_COUNT;
            }
            else
            {
                pool = OLD_MAZE_ITEMS;
                poolSize = OLD_MAZE_ITEM_COUNT;
            }
        }
        else if (roomType == ROOM_LABORATORY ||
                 roomType == ROOM_TESTING)
        {
            if (categoryRoll < 45)
            {
                pool = OLD_MAZE_ITEMS;
                poolSize = OLD_MAZE_ITEM_COUNT;
            }
            else if (categoryRoll < 80)
            {
                pool = CREATURE_ITEMS;
                poolSize = CREATURE_ITEM_COUNT;
            }
            else
            {
                pool = NORMAL_ITEMS;
                poolSize = NORMAL_ITEM_COUNT;
            }
        }
        else if (categoryRoll < 45)
        {
            pool = OLD_MAZE_ITEMS;
            poolSize = OLD_MAZE_ITEM_COUNT;
        }
        else if (categoryRoll < 75)
        {
            pool = NORMAL_ITEMS;
            poolSize = NORMAL_ITEM_COUNT;
        }
        else
        {
            pool = CREATURE_ITEMS;
            poolSize = CREATURE_ITEM_COUNT;
        }
    }
    else
    {
        int categoryRoll = std::rand() % 100;

        if (roomType == ROOM_RITUAL_CHAMBER)
        {
            if (categoryRoll < 70)
            {
                pool = ANCIENT_ITEMS;
                poolSize = ANCIENT_ITEM_COUNT;
            }
            else
            {
                pool = CREATURE_ITEMS;
                poolSize = CREATURE_ITEM_COUNT;
            }
        }
        else if (roomType == ROOM_FUNGUS_GROWTH ||
                 roomType == ROOM_WASTE_PROCESSING)
        {
            if (categoryRoll < 60)
            {
                pool = CREATURE_ITEMS;
                poolSize = CREATURE_ITEM_COUNT;
            }
            else
            {
                pool = ANCIENT_ITEMS;
                poolSize = ANCIENT_ITEM_COUNT;
            }
        }
        else if (categoryRoll < 45)
        {
            pool = ANCIENT_ITEMS;
            poolSize = ANCIENT_ITEM_COUNT;
        }
        else if (categoryRoll < 75)
        {
            pool = CREATURE_ITEMS;
            poolSize = CREATURE_ITEM_COUNT;
        }
        else
        {
            pool = OLD_MAZE_ITEMS;
            poolSize = OLD_MAZE_ITEM_COUNT;
        }
    }

    const ItemInfo &chosen =
        pool[std::rand() % poolSize];

    int baseValue =
        chosen.minValue +
        (std::rand() %
         (chosen.maxValue - chosen.minValue + 1));

    return new Item(
        chosen.name,
        baseValue,
        chosen.lore,
        chosen.category,
        chosen.valueKnown,
        chosen.loreTitle,
        chosen.loreEntry);
}

Monster *Maze::generateRandomMonster(int currentDay)
{
    const MonsterInfo *pool = nullptr;
    int poolSize = 0;

    int roll = std::rand() % 100;

    int commonLimit =
        60 - (currentDay * 20);

    int uncommonLimit =
        commonLimit + 15 + currentDay * 15;

    if (roll < commonLimit)
    {
        pool = COMMON_M;
        poolSize = COMMON_MCOUNT;
    }
    else if (roll < uncommonLimit)
    {
        pool = UNCOMMON_M;
        poolSize = UNCOMMON_MCOUNT;
    }
    else
    {
        pool = RARE_M;
        poolSize = RARE_MCOUNT;
    }

    const MonsterInfo &chosen =
        pool[std::rand() % poolSize];

    int difficulty =
        chosen.baseDifficulty +
        (currentDay - 1);

    if (difficulty < 1)
        difficulty = 1;

    if (difficulty > 3)
        difficulty = 3;

    return new Monster(
        chosen.name,
        difficulty,
        chosen.description);
}

RoomType Maze::chooseRoomType(int currentDay) const
{
    int roll = std::rand() % 100;

    if (currentDay == 1)
    {
        if (roll < 25)
            return ROOM_STORAGE;
        if (roll < 45)
            return ROOM_MAINTENANCE;
        if (roll < 62)
            return ROOM_OFFICE;
        if (roll < 77)
            return ROOM_WASTE_PROCESSING;

        return ROOM_HALLWAY;
    }

    if (currentDay == 2)
    {
        if (roll < 20)
            return ROOM_LABORATORY;
        if (roll < 40)
            return ROOM_TESTING;
        if (roll < 58)
            return ROOM_FUNGUS_GROWTH;
        if (roll < 73)
            return ROOM_WASTE_PROCESSING;
        if (roll < 88)
            return ROOM_MAINTENANCE;

        return ROOM_HALLWAY;
    }

    if (roll < 25)
        return ROOM_RITUAL_CHAMBER;
    if (roll < 40)
        return ROOM_LABORATORY;
    if (roll < 56)
        return ROOM_FUNGUS_GROWTH;
    if (roll < 71)
        return ROOM_TESTING;
    if (roll < 83)
        return ROOM_WASTE_PROCESSING;
    if (roll < 93)
        return ROOM_MAINTENANCE;

    return ROOM_HALLWAY;
}

void Maze::assignRoomTypes(int currentDay)
{
    for (int r = 0; r < rows; r++)
    {
        for (int c = 0; c < cols; c++)
        {
            grid[r][c].setType(
                chooseRoomType(currentDay));
        }
    }
}

int Maze::getItemSpawnModifier(RoomType type) const
{
    switch (type)
    {
    case ROOM_STORAGE:
        return 18;

    case ROOM_OFFICE:
        return 12;

    case ROOM_LABORATORY:
    case ROOM_TESTING:
    case ROOM_RITUAL_CHAMBER:
        return 8;

    case ROOM_HALLWAY:
        return -12;

    case ROOM_FUNGUS_GROWTH:
    case ROOM_WASTE_PROCESSING:
        return -5;

    default:
        return 0;
    }
}

int Maze::getMonsterSpawnModifier(RoomType type) const
{
    switch (type)
    {
    case ROOM_RITUAL_CHAMBER:
        return 18;

    case ROOM_FUNGUS_GROWTH:
    case ROOM_TESTING:
    case ROOM_WASTE_PROCESSING:
        return 10;

    case ROOM_OFFICE:
    case ROOM_STORAGE:
        return -10;

    case ROOM_HALLWAY:
        return -5;

    default:
        return 0;
    }
}

void Maze::placeExit(int startR, int startC)
{
    // Breadth-first search measures distance through the carved hallways,
    // not simple straight-line distance. The exit therefore requires real exploration.
    std::vector<std::vector<int>> distance(
        rows,
        std::vector<int>(cols, -1));

    std::queue<std::pair<int, int>> roomsToCheck;

    distance[startR][startC] = 0;
    roomsToCheck.push({startR, startC});

    int farthestDistance = 0;
    std::vector<std::pair<int, int>> farthestRooms;

    while (!roomsToCheck.empty())
    {
        int r = roomsToCheck.front().first;
        int c = roomsToCheck.front().second;
        roomsToCheck.pop();

        int currentDistance = distance[r][c];

        if (currentDistance > farthestDistance)
        {
            farthestDistance = currentDistance;
            farthestRooms.clear();
            farthestRooms.push_back({r, c});
        }
        else if (currentDistance == farthestDistance && currentDistance > 0)
        {
            farthestRooms.push_back({r, c});
        }

        const Room &room = grid[r][c];

        if (room.isOpenTop() && distance[r - 1][c] == -1)
        {
            distance[r - 1][c] = currentDistance + 1;
            roomsToCheck.push({r - 1, c});
        }

        if (room.isOpenBottom() && distance[r + 1][c] == -1)
        {
            distance[r + 1][c] = currentDistance + 1;
            roomsToCheck.push({r + 1, c});
        }

        if (room.isOpenLeft() && distance[r][c - 1] == -1)
        {
            distance[r][c - 1] = currentDistance + 1;
            roomsToCheck.push({r, c - 1});
        }

        if (room.isOpenRight() && distance[r][c + 1] == -1)
        {
            distance[r][c + 1] = currentDistance + 1;
            roomsToCheck.push({r, c + 1});
        }
    }

    if (farthestRooms.empty())
        return;

    const std::pair<int, int> &exitPosition =
        farthestRooms[std::rand() % farthestRooms.size()];

    grid[exitPosition.first][exitPosition.second].setExit(true);
}

void Maze::generateMaze(int currentDay)
{
    dayTheme = currentDay;

    // 1) Reset every room before carving the next maze.
    for (int r = 0; r < rows; r++)
    {
        for (int c = 0; c < cols; c++)
        {
            Room &room = grid[r][c];

            room.setOpenTop(false);
            room.setOpenBottom(false);
            room.setOpenLeft(false);
            room.setOpenRight(false);

            room.setVisited(false);
            room.setExit(false);
            room.setType(ROOM_HALLWAY);
            room.setPlayerNote("");

            if (room.getItem())
            {
                delete room.getItem();
                room.setItem(nullptr);
            }

            if (room.getMonster())
            {
                delete room.getMonster();
                room.setMonster(nullptr);
            }
        }
    }

    // 2) Carve one connected maze using recursive backtracking.
    int carveStartR = std::rand() % rows;
    int carveStartC = std::rand() % cols;

    generateRecursive(carveStartR, carveStartC);

    // Recursive generation temporarily uses visited to track carved rooms.
    // Reset it so the same property can now track PLAYER exploration.
    for (int r = 0; r < rows; r++)
    {
        for (int c = 0; c < cols; c++)
            grid[r][c].setVisited(false);
    }

    // 3) Give rooms a day-specific identity and place a physical exit.
    assignRoomTypes(currentDay);
    placeExit(rows / 2, cols / 2);

    // 4) Populate rooms. Their types slightly change spawn chances.
    for (int r = 0; r < rows; r++)
    {
        for (int c = 0; c < cols; c++)
        {
            Room &room = grid[r][c];

            // The center is the player's safe arrival room.
            // The exit also stays clear so leaving is a deliberate choice.
            if ((r == rows / 2 && c == cols / 2) || room.isExit())
                continue;

            int itemSpawnChance =
                25 + (currentDay * 20) +
                getItemSpawnModifier(room.getType());

            itemSpawnChance =
                std::max(10, std::min(itemSpawnChance, 90));

            if ((std::rand() % 100) < itemSpawnChance)
            {
                room.setItem(
                    generateRandomItem(
                        currentDay,
                        room.getType()));
            }

            int monsterSpawnChance =
                30 + (currentDay * 15) +
                getMonsterSpawnModifier(room.getType());

            monsterSpawnChance =
                std::max(10, std::min(monsterSpawnChance, 90));

            if ((std::rand() % 100) < monsterSpawnChance)
            {
                room.setMonster(
                    generateRandomMonster(currentDay));
            }
        }
    }
}

void Maze::generateRecursive(int r, int c)
{
    grid[r][c].setVisited(true);

    int directions[4] = {0, 1, 2, 3};

    for (int i = 0; i < 4; i++)
    {
        int j = std::rand() % 4;

        std::swap(
            directions[i],
            directions[j]);
    }

    for (int i = 0; i < 4; i++)
    {
        int dir = directions[i];
        int newR = r;
        int newC = c;

        if (dir == 0 && r > 0)
            newR--;
        else if (dir == 1 && r < rows - 1)
            newR++;
        else if (dir == 2 && c > 0)
            newC--;
        else if (dir == 3 && c < cols - 1)
            newC++;
        else
            continue;

        if (!grid[newR][newC].isVisited())
        {
            if (dir == 0)
            {
                grid[r][c].setOpenTop(true);
                grid[newR][newC].setOpenBottom(true);
            }
            else if (dir == 1)
            {
                grid[r][c].setOpenBottom(true);
                grid[newR][newC].setOpenTop(true);
            }
            else if (dir == 2)
            {
                grid[r][c].setOpenLeft(true);
                grid[newR][newC].setOpenRight(true);
            }
            else
            {
                grid[r][c].setOpenRight(true);
                grid[newR][newC].setOpenLeft(true);
            }

            generateRecursive(newR, newC);
        }
    }
}

std::string Maze::getRoomTypeName(RoomType type) const
{
    switch (type)
    {
    case ROOM_STORAGE:
        return "COMPANY STORAGE";
    case ROOM_MAINTENANCE:
        return "MAINTENANCE SECTOR";
    case ROOM_LABORATORY:
        return "SEALED LABORATORY";
    case ROOM_OFFICE:
        return "EMPLOYEE OFFICE";
    case ROOM_WASTE_PROCESSING:
        return "WASTE PROCESSING";
    case ROOM_RITUAL_CHAMBER:
        return "RITUAL CHAMBER";
    case ROOM_FUNGUS_GROWTH:
        return "FUNGUS GROWTH";
    case ROOM_TESTING:
        return "ABANDONED TESTING ROOM";
    case ROOM_EXIT:
        return "DESIGNATED EXIT";
    case ROOM_HALLWAY:
    default:
        return "HALLWAY / JUNCTION";
    }
}

std::string Maze::getRoomFlavor(RoomType type, int currentDay) const
{
    switch (type)
    {
    case ROOM_STORAGE:
        return "Dusty company property is stacked wherever gravity permitted.";
    case ROOM_MAINTENANCE:
        return currentDay == 1
                   ? "Old machinery coughs beneath a handwritten OUT OF ORDER sign."
                   : "The pipes vibrate like something is crawling through them.";
    case ROOM_LABORATORY:
        return currentDay == 2
                   ? "Observation glass faces a chair with too many restraints."
                   : "Modern monitors study something much older than electricity.";
    case ROOM_OFFICE:
        return "A dead telephone rings once, realizes its mistake, and stops.";
    case ROOM_WASTE_PROCESSING:
        return "The drainage grate is breathing at a calm, professional pace.";
    case ROOM_RITUAL_CHAMBER:
        return "Company cables have been carefully plugged into an ancient altar.";
    case ROOM_FUNGUS_GROWTH:
        return "Pale fungus turns toward you despite having no visible face.";
    case ROOM_TESTING:
        return "A clipboard records test subjects by employee number, not name.";
    case ROOM_EXIT:
        return "A freight lift waits here. The call button is warm.";
    case ROOM_HALLWAY:
    default:
        return currentDay == 3
                   ? "The corridor bends at angles the building should not contain."
                   : "Every hallway sign points back toward Slightly Dangerous LLC.";
    }
}

void Maze::displayRoom(int r, int c, bool firstVisit) const
{
    const Room &current = grid[r][c];

    const int height = 15;
    const int width = 51;

    std::vector<std::string> canvas(
        height,
        std::string(width, ' '));

    // Draw the outer walls.
    for (int col = 1; col < width - 1; col++)
    {
        canvas[0][col] = '-';
        canvas[height - 1][col] = '-';
    }

    for (int row = 1; row < height - 1; row++)
    {
        canvas[row][0] = '|';
        canvas[row][width - 1] = '|';
    }

    canvas[0][0] = '+';
    canvas[0][width - 1] = '+';
    canvas[height - 1][0] = '+';
    canvas[height - 1][width - 1] = '+';

    // Cut visible doorways through the corresponding walls.
    for (int offset = -2; offset <= 2; offset++)
    {
        if (current.isOpenTop())
            canvas[0][width / 2 + offset] = ' ';

        if (current.isOpenBottom())
            canvas[height - 1][width / 2 + offset] = ' ';
    }

    for (int offset = -1; offset <= 1; offset++)
    {
        if (current.isOpenLeft())
            canvas[height / 2 + offset][0] = ' ';

        if (current.isOpenRight())
            canvas[height / 2 + offset][width - 1] = ' ';
    }

    // Each room type gets compact ASCII props instead of text labels.
    switch (current.getType())
    {
    case ROOM_STORAGE:
        placeArt(canvas, 2, 3, {
            "+-------+",
            "|\\  /\\  |",
            "| \\/  \\ |",
            "+-------+"});
        placeArt(canvas, 9, 36, {
            "  _______",
            " /______/|",
            "|      | |",
            "|______|/"});
        break;

    case ROOM_MAINTENANCE:
        placeArt(canvas, 2, 3, {
            "o====+-----+",
            "     | (O) |==o",
            "o====+-----+",
            "       | |"});
        placeArt(canvas, 9, 38, {
            "  \\  /",
            "---XX---",
            "  /  \\"});
        break;

    case ROOM_LABORATORY:
        placeArt(canvas, 2, 3, {
            "  __  __  __",
            " |  ||  ||  |",
            " |~~||~~||~~|",
            "  \\_/ \\_/ \\_/"});
        placeArt(canvas, 9, 37, {
            ".---------.",
            "|  /\\_/\\  |",
            "|_/     \\_|",
            "'----+----'"});
        break;

    case ROOM_OFFICE:
        placeArt(canvas, 2, 3, {
            "   ______",
            "  / ____ \\",
            " ( (____) )",
            "  \\__||__/"});
        placeArt(canvas, 9, 35, {
            " ___________",
            "|___________|",
            "  |       |",
            " _|_     _|_"});
        break;

    case ROOM_WASTE_PROCESSING:
        placeArt(canvas, 2, 3, {
            " .----. .----.",
            "/      X      \\",
            "|  ()  |  ()  |",
            "\\______X______/"});
        placeArt(canvas, 9, 36, {
            "~~~~~~~~~~~",
            "|#|#|#|#|#|",
            "|#|#|#|#|#|",
            "~~~~~~~~~~~"});
        break;

    case ROOM_RITUAL_CHAMBER:
        placeArt(canvas, 2, 4, {
            "  \\  |  /",
            "---'<o>'---",
            "  /  |  \\",
            "     V"});
        placeArt(canvas, 9, 37, {
            "   /\\",
            "  /__\\",
            " /|  |\\",
            "/_|__|_\\"});
        break;

    case ROOM_FUNGUS_GROWTH:
        placeArt(canvas, 2, 3, {
            "   ___    _",
            " _/o o\\_ /o\\",
            "   | |   | |",
            ".._| |...| |.."});
        placeArt(canvas, 9, 38, {
            " .  o  .",
            "o  .  o  .",
            " .  /\\  o",
            ".../  \\..."});
        break;

    case ROOM_TESTING:
        placeArt(canvas, 2, 3, {
            "  _______",
            " /  o  /|",
            "+-----+ |",
            "   \\____|"});
        placeArt(canvas, 9, 38, {
            "  .---.",
            "  | X |",
            " _|___|_",
            "|_|   |_|"});
        break;

    case ROOM_EXIT:
        placeArt(canvas, 2, 16, {
            "+----------------+",
            "|       /\\       |",
            "|      /  \\      |",
            "|     |    |     |",
            "|     |    |     |",
            "|     |    |     |",
            "|     |    |     |",
            "|     |    |     |",
            "|_____|____|_____|",
            "      (  Q  )"});
        break;

    case ROOM_HALLWAY:
    default:
        placeArt(canvas, 2, 3, {
            " .------------.",
            " |  ?  <--->  |",
            " '------.-----'",
            "        |"});
        placeArt(canvas, 10, 39, {
            "\\  |  /",
            " --*--",
            "/  |  \\"});
        break;
    }

    // Revisited rooms receive a small visual reminder in addition to the label.
    if (!firstVisit)
        placeText(canvas, height - 2, 3, "////");

    // Room contents use separate positions so items and monsters never overlap.
    if (current.getItem() && !current.getItem()->isCollected())
        canvas[5][width - 8] = '$';

    if (current.getMonster() && !current.getMonster()->isDefeated())
        canvas[10][7] = 'M';

    canvas[height / 2][width / 2] = 'P';

    std::cout << (firstVisit
                      ? "[ UNMAPPED ROOM ]\n"
                      : "[ PREVIOUSLY VISITED ]\n");

    std::cout << "SECTOR "
              << static_cast<char>('A' + r)
              << "-"
              << (c + 1)
              << " | "
              << getRoomTypeName(current.getType())
              << "\n";

    std::cout << getRoomFlavor(current.getType(), dayTheme)
              << "\n";

    if (!current.getPlayerNote().empty())
    {
        std::cout << "Map note: ["
                  << current.getPlayerNote()
                  << "]\n";
    }

    std::cout << "\n";

    for (const std::string &line : canvas)
        std::cout << line << "\n";
}

bool Maze::hasVisitedNeighbor(int r, int c) const
{
    const Room &room = grid[r][c];

    if (room.isOpenTop() && r > 0 && grid[r - 1][c].isVisited())
        return true;

    if (room.isOpenBottom() && r < rows - 1 && grid[r + 1][c].isVisited())
        return true;

    if (room.isOpenLeft() && c > 0 && grid[r][c - 1].isVisited())
        return true;

    if (room.isOpenRight() && c < cols - 1 && grid[r][c + 1].isVisited())
        return true;

    return false;
}

void Maze::displayMap(int playerRow, int playerCol) const
{
    const int mapHeight = rows * 2 - 1;
    const int mapWidth = cols * 4 - 3;

    std::vector<std::string> map(
        mapHeight,
        std::string(mapWidth, ' '));

    // A visited room reveals the doors leading out of it, but the room beyond
    // remains unknown until the player actually enters it.
    for (int r = 0; r < rows; r++)
    {
        for (int c = 0; c < cols; c++)
        {
            const Room &room = grid[r][c];

            if (!room.isVisited())
                continue;

            int mapRow = r * 2;
            int mapCol = c * 4;

            if (room.isOpenRight() && c < cols - 1)
            {
                map[mapRow][mapCol + 1] = '-';
                map[mapRow][mapCol + 2] = '-';
                map[mapRow][mapCol + 3] = '-';
            }

            if (room.isOpenBottom() && r < rows - 1)
                map[mapRow + 1][mapCol] = '|';

            if (room.isOpenLeft() && c > 0)
            {
                map[mapRow][mapCol - 1] = '-';
                map[mapRow][mapCol - 2] = '-';
                map[mapRow][mapCol - 3] = '-';
            }

            if (room.isOpenTop() && r > 0)
                map[mapRow - 1][mapCol] = '|';
        }
    }

    // Draw known rooms, frontier rooms, and the player's current position.
    for (int r = 0; r < rows; r++)
    {
        for (int c = 0; c < cols; c++)
        {
            const Room &room = grid[r][c];

            bool visible =
                room.isVisited() ||
                hasVisitedNeighbor(r, c);

            if (!visible)
                continue;

            char symbol = '?';

            if (room.isVisited())
            {
                if (r == playerRow && c == playerCol)
                    symbol = '@';
                else if (room.isExit())
                    symbol = 'E';
                else if (!room.getPlayerNote().empty())
                    symbol = room.getPlayerNote()[0];
                else
                    symbol = '#';
            }

            map[r * 2][c * 4] = symbol;
        }
    }

    std::cout << "        SLIGHTLY DANGEROUS LLC\n";
    std::cout << "             PERSONAL MAP\n\n";

    for (const std::string &line : map)
        std::cout << "        " << line << "\n";

    const Room &current = grid[playerRow][playerCol];

    std::cout << "\n@  You\n";
    std::cout << "#  Explored room\n";
    std::cout << "?  Unknown room behind a discovered door\n";
    std::cout << "E  Discovered exit\n";
    std::cout << "X/$/!/?  Your room notes\n";

    if (!current.getPlayerNote().empty())
    {
        std::cout << "\nCurrent room note: ["
                  << current.getPlayerNote()
                  << "]\n";
    }
}
