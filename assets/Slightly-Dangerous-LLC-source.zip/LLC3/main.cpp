// main.cpp - main game loop for Slightly Dangerous LLC
#include <cstdlib> // srand, rand
#include <ctime>   // time
#include <iostream>
#include <string>

#include "animation.h"
#include "hud.h"
#include "item.h"
#include "maze.h"
#include "minigame.h"
#include "monster.h"
#include "player.h"
#include "room.h"
#include "story.h"
#include "utils.h"

// Information that belongs to each of the three current work days.
struct DayInfo
{
    int quota;
    std::string shiftName;
    std::string atmosphere;
};

const int TOTAL_DAYS = 3;

const DayInfo DAYS[TOTAL_DAYS] = {
    {50,
     "Upper Storage Wing",
     "The upper maze looks almost like a normal industrial building. Almost. The fluorescent lights buzz too loudly, and Sketch has advised you not to touch anything that is breathing."},

    {200,
     "Lower Testing Wing",
     "The walls are older down here. Damp fungus grows around sealed doors, and several company signs have been bolted over symbols carved directly into the concrete."},

    {600,
     "Original Facility Access",
     "Sketch stops joking before opening the final elevator. The rooms below predate most of the company equipment installed inside them. He refuses to explain by how much."}};

// Opens the discovered-only map and lets the player mark their current room.
static void openPersonalMap(
    Maze &maze,
    const Player &player)
{
    while (true)
    {
        clearScreen();

        maze.displayMap(
            player.getRow(),
            player.getCol());

        std::cout << "\n[N] Add/Edit Note for Current Room\n";
        std::cout << "[M] Close Map\n";
        std::cout << "\nChoice: ";

        char choice = getCharChoice("NM");

        if (choice == 'M')
            return;

        clearScreen();

        displayHeader(
            "ROOM NOTE",
            44);

        std::cout << "X = dangerous monster\n";
        std::cout << "$ = useful loot\n";
        std::cout << "! = something weird\n";
        std::cout << "? = investigate later\n";
        std::cout << "C = clear existing note\n\n";
        std::cout << "Marker: ";

        char marker = getCharChoice("X$!?C");

        Room &currentRoom =
            maze.getRoom(
                player.getRow(),
                player.getCol());

        if (marker == 'C')
            currentRoom.setPlayerNote("");
        else
            currentRoom.setPlayerNote(
                std::string(1, marker));

        playSoundEffect(SOUND_MENU);
    }
}

// Opens the carried loot list and the permanent lore journal.
static void openInventoryMenu(
    const Player &player)
{
    while (true)
    {
        displayInventoryScreen(player);

        std::cout << "\n[J] Read Lore Journal  [B] Back\n";
        std::cout << "Choice: ";

        char choice = getCharChoice("JB");

        if (choice == 'B')
            return;

        displayLoreJournal(player);
        waitForKey();
    }
}

// Lets the player keep, leave, or swap a newly discovered item.
static void handleItemDiscovery(
    Player &player,
    Room &room)
{
    Item *roomItem = room.getItem();

    if (!roomItem || roomItem->isCollected())
        return;

    int oldLoreCount =
        static_cast<int>(player.getLoreJournal().size());

    displayItemDiscovery(*roomItem);

    if (!player.isInventoryFull())
    {
        std::cout << "\n[K] Keep Item  [L] Leave It\n";
        std::cout << "Choice: ";

        char choice = getCharChoice("KL");

        if (choice == 'L')
        {
            std::cout << "\nYou leave the "
                      << roomItem->getName()
                      << " where you found it.\n";

            waitForKey();
            return;
        }

        player.addToInventory(*roomItem);
        roomItem->setCollected(true);

        std::cout << "\nAdded to inventory ("
                  << player.getInventoryCount()
                  << "/"
                  << Player::INVENTORY_CAPACITY
                  << ").\n";
    }
    else
    {
        std::cout << "\nYour inventory is full.\n";
        std::cout << "Press Enter to choose an item to replace.";

        std::string input;
        std::getline(std::cin, input);

        displayInventoryScreen(player);

        std::cout << "\nFound: "
                  << roomItem->getName()
                  << "\n";

        std::cout << "Choose slot 1-"
                  << Player::INVENTORY_CAPACITY
                  << " to replace, or 0 to leave it: ";

        int slot =
            getIntInRange(
                0,
                Player::INVENTORY_CAPACITY);

        if (slot == 0)
        {
            std::cout << "\nYou leave the new item behind.\n";
            waitForKey();
            return;
        }

        std::string newItemName =
            roomItem->getName();

        Item droppedItem =
            player.replaceInventoryItem(
                slot - 1,
                *roomItem);

        // The replaced item is placed in this room and can be recovered later.
        *roomItem = droppedItem;
        roomItem->setCollected(false);

        std::cout << "\nYou keep the "
                  << newItemName
                  << " and leave the "
                  << droppedItem.getName()
                  << " in this room.\n";
    }

    if (static_cast<int>(player.getLoreJournal().size()) > oldLoreCount)
    {
        setTextColor(COLOR_MAGENTA);
        std::cout << "\nNEW LORE RECORDED. Read it from your inventory menu.\n";
        resetTextColor();
    }

    waitForKey();
}

// Shows the risk / reward decision without forcing the player to leave.
static bool confirmExitChoice(
    const Player &player,
    int quota)
{
    clearScreen();

    displayHeader(
        "DESIGNATED EXIT",
        48);

    std::cout << "The freight lift doors shudder open.\n\n";

    std::cout << "Banked money: $"
              << player.getMoney()
              << "\n";

    std::cout << "Known loot estimate: $"
              << player.getKnownInventoryValue()
              << "\n";

    if (player.getUnknownValueCount() > 0)
    {
        std::cout << "Unknown-value items: "
                  << player.getUnknownValueCount()
                  << "\n";
    }

    std::cout << "Required quota: $"
              << quota
              << "\n\n";

    int knownTotal =
        player.getMoney() +
        player.getKnownInventoryValue();

    if (knownTotal >= quota)
    {
        setTextColor(COLOR_GREEN);

        std::cout << "Your known total covers the quota.\n";

        resetTextColor();
    }
    else if (player.getUnknownValueCount() > 0)
    {
        setTextColor(COLOR_YELLOW);

        std::cout << "Your known total is $"
                  << (quota - knownTotal)
                  << " short, but the scanner has not appraised your unknown items.\n";

        resetTextColor();
    }
    else
    {
        setTextColor(COLOR_RED);

        std::cout << "You are $"
                  << (quota - knownTotal)
                  << " short. Leaving now will fail the shift.\n";

        resetTextColor();
    }

    std::cout << "\nLeaving turns in every carried item. Continue? (Y/N): ";

    return getCharChoice("YN") == 'Y';
}

int main()
{
    std::srand(static_cast<unsigned>(std::time(nullptr))); // seed random number generator once when the program starts

    int menuResult = displayMenu();
    if (menuResult == 0)
        return 0;

    std::string playerName = runOpeningSequence();

    if (playerName.empty()) // player refused Sketch's employment offer
        return 0;

    Player player(playerName);
    Maze maze(5, 5);

    int currentDay = 1;

    player.setPosition(
        maze.getRows() / 2,
        maze.getCols() / 2);

    maze.generateMaze(currentDay);

    displayShiftIntro(
        player,
        currentDay,
        DAYS[currentDay - 1].shiftName,
        DAYS[currentDay - 1].atmosphere,
        DAYS[currentDay - 1].quota);

    // True whenever the player has just moved into a room.
    // Room contents only activate on entry, not every time the screen redraws.
    bool enteredRoom = true;

    while (true)
    {
        const DayInfo &dayInfo =
            DAYS[currentDay - 1];

        Room &currentRoom =
            maze.getRoom(
                player.getRow(),
                player.getCol());

        bool firstVisit = false;

        if (enteredRoom && !currentRoom.isVisited())
        {
            firstVisit = true;
            currentRoom.setVisited(true);
        }

        clearScreen();

        displayHUD(
            player,
            currentDay,
            dayInfo.quota,
            dayInfo.shiftName);

        maze.displayRoom(
            player.getRow(),
            player.getCol(),
            firstVisit);

        // Items and monsters activate once when the player enters the room.
        if (enteredRoom)
        {
            enteredRoom = false;
            bool openedEventScreen = false;

            if (currentRoom.getItem() &&
                !currentRoom.getItem()->isCollected())
            {
                handleItemDiscovery(
                    player,
                    currentRoom);

                openedEventScreen = true;
            }

            if (currentRoom.getMonster() &&
                !currentRoom.getMonster()->isDefeated())
            {
                Monster *monster = currentRoom.getMonster();
                std::string monsterName = monster->getName();

                displayMonsterEncounter(
                    monsterName,
                    monster->getDesc());

                bool win = false;
                int difficulty = monster->getDifficulty();

                if (difficulty == 1)
                    win = (std::rand() % 2
                               ? vending(monsterName)
                               : dodge(monsterName));

                else if (difficulty == 2)
                    win = (std::rand() % 2
                               ? code(monsterName)
                               : company(monsterName));

                else
                    win = (std::rand() % 2
                               ? memorize(monsterName)
                               : shake(monsterName));

                if (win)
                {
                    monster->setDefeated(true);

                    displayMonsterDefeated(monsterName);

                    delete monster;
                    currentRoom.setMonster(nullptr);
                }
                else
                {
                    player.loseHeart();

                    displayMonsterHit(
                        monsterName,
                        player.getHearts());

                    if (player.getHearts() <= 0)
                    {
                        displayGameOver(player);
                        return 0;
                    }
                }

                openedEventScreen = true;
            }

            // Event screens clear the console, so redraw the room before asking
            // for movement instead of placing the prompt under an old screen.
            if (openedEventScreen)
                continue;
        }

        std::cout << "\n[W/A/S/D] Move  [M] Map  [I] Inventory  [Q] Attempt Exit\n";
        std::cout << "Choice: ";

        char input = getCharChoice("WASDMIQ");

        if (input == 'M')
        {
            openPersonalMap(maze, player);
            continue;
        }

        if (input == 'I')
        {
            openInventoryMenu(player);
            continue;
        }

        if (input == 'Q')
        {
            if (!currentRoom.isExit())
            {
                std::cout << "\nThere is no exit here. The company neglected to install teleportation.\n";
                waitForKey();
                continue;
            }

            if (!confirmExitChoice(player, dayInfo.quota))
                continue;

            displayTurnInReceipt(player);
            player.turnInInventory();

            if (player.getMoney() < dayInfo.quota)
            {
                displayGameOver(player);
                return 0;
            }

            displayDayComplete(currentDay, player);

            player.addMoney(-dayInfo.quota); // Sketch takes the day's required amount
            currentDay++;

            if (currentDay > TOTAL_DAYS)
            {
                displayGameWon(player);
                return 0;
            }

            player.resetHearts();

            maze.generateMaze(currentDay);

            player.setPosition(
                maze.getRows() / 2,
                maze.getCols() / 2);

            displayShiftIntro(
                player,
                currentDay,
                DAYS[currentDay - 1].shiftName,
                DAYS[currentDay - 1].atmosphere,
                DAYS[currentDay - 1].quota);

            enteredRoom = true;
            continue;
        }

        bool canMove =
            (input == 'W' && currentRoom.isOpenTop()) ||
            (input == 'S' && currentRoom.isOpenBottom()) ||
            (input == 'A' && currentRoom.isOpenLeft()) ||
            (input == 'D' && currentRoom.isOpenRight());

        if (!canMove)
        {
            std::cout << "\nYou bump into a wall. It feels slightly offended.\n";
            waitForKey();
            continue;
        }

        int newR = player.getRow();
        int newC = player.getCol();

        if (input == 'W')
            newR--;
        else if (input == 'S')
            newR++;
        else if (input == 'A')
            newC--;
        else if (input == 'D')
            newC++;

        char animationDirection =
            (input == 'W' ? 'U' :
             input == 'S' ? 'D'
                          : input == 'A' ? 'L'
                                         : 'R');

        animatePlayerWalk(animationDirection);

        player.setPosition(newR, newC);
        enteredRoom = true;
    }

    return 0;
}
