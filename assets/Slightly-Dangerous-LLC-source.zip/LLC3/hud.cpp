// hud.cpp - implementation of display related screens and HUD visuals
#include "hud.h"
#include "utils.h"

#include <iomanip>
#include <iostream>

void displayHUD(
    const Player &player,
    int day,
    int quota,
    const std::string &shiftName)
{
    displayHeader(
        "Slightly Dangerous LLC - Salvage Shift",
        50);

    setTextColor(COLOR_CYAN);

    std::cout << " Employee: "
              << player.getName();

    resetTextColor();

    std::cout << " | Day: "
              << day
              << "\n";

    std::cout << " Assignment: "
              << shiftName
              << "\n";

    setTextColor(COLOR_GREEN);

    std::cout << " Banked: $"
              << player.getMoney();

    resetTextColor();

    std::cout << " | ";

    if (player.getHearts() <= 1)
        setTextColor(COLOR_RED);
    else
        setTextColor(COLOR_WHITE);

    std::cout << "Hearts: "
              << player.getHearts();

    resetTextColor();

    std::cout << " | ";

    setTextColor(COLOR_YELLOW);

    std::cout << "Quota: $"
              << quota
              << "\n";

    resetTextColor();

    std::cout << " Inventory: "
              << player.getInventoryCount()
              << "/"
              << Player::INVENTORY_CAPACITY
              << " | Known loot estimate: $"
              << player.getKnownInventoryValue();

    if (player.getUnknownValueCount() > 0)
    {
        std::cout << " + "
                  << player.getUnknownValueCount()
                  << " unknown";
    }

    std::cout << "\n";

    std::cout << std::string(50, '=')
              << "\n\n";
}

void displayItemDiscovery(const Item &item)
{
    clearScreen();

    playSoundEffect(SOUND_PICKUP);

    setTextColor(COLOR_GREEN);

    displayHeader(
        "ITEM FOUND",
        42);

    resetTextColor();

    std::cout << "\n>> "
              << item.getName()
              << " <<\n\n";

    std::cout << "Category: "
              << item.getCategoryName()
              << "\n";

    std::cout << "Estimated value: ";

    if (item.isValueKnown())
        std::cout << "$" << item.getValue();
    else
        std::cout << "$???";

    std::cout << "\n";

    if (!item.getLore().empty())
    {
        std::cout << "\n"
                  << item.getLore()
                  << "\n";
    }

    if (item.containsLore())
    {
        setTextColor(COLOR_MAGENTA);
        std::cout << "\nThis may contain information worth recording.\n";
        resetTextColor();
    }
}

void displayInventoryScreen(const Player &player)
{
    clearScreen();

    displayHeader(
        "INVENTORY",
        58);

    const std::vector<Item> &items =
        player.getInventory();

    if (items.empty())
    {
        std::cout << "\nYour bag contains one alarming amount of empty space.\n";
    }
    else
    {
        std::cout << "\n";

        for (int i = 0; i < static_cast<int>(items.size()); i++)
        {
            const Item &item = items[i];

            std::cout << std::right
                      << std::setw(2)
                      << (i + 1)
                      << ". "
                      << std::left
                      << std::setw(31)
                      << item.getName();

            if (item.isValueKnown())
                std::cout << "$" << item.getValue();
            else
                std::cout << "$???";

            std::cout << "\n";
        }
    }

    std::cout << "\n"
              << std::string(58, '-')
              << "\n";

    std::cout << "Inventory: "
              << player.getInventoryCount()
              << "/"
              << Player::INVENTORY_CAPACITY
              << "\n";

    std::cout << "Known estimated value: $"
              << player.getKnownInventoryValue()
              << "\n";

    if (player.getUnknownValueCount() > 0)
    {
        std::cout << "Unknown-value items: "
                  << player.getUnknownValueCount()
                  << "\n";
    }

    std::cout << "Lore entries recovered: "
              << player.getLoreJournal().size()
              << "\n";
}

void displayLoreJournal(const Player &player)
{
    clearScreen();

    displayHeader(
        "RECOVERED LORE",
        64);

    const std::vector<LoreRecord> &entries =
        player.getLoreJournal();

    if (entries.empty())
    {
        std::cout << "\nNo useful secrets yet. Just regular workplace violations.\n";
        return;
    }

    for (int i = 0; i < static_cast<int>(entries.size()); i++)
    {
        setTextColor(COLOR_MAGENTA);

        std::cout << "\n["
                  << (i + 1)
                  << "] "
                  << entries[i].title
                  << "\n";

        resetTextColor();

        std::cout << entries[i].text
                  << "\n";
    }
}

void displayTurnInReceipt(const Player &player)
{
    clearScreen();

    playSoundEffect(SOUND_SUCCESS);

    displayHeader(
        "EXIT APPRAISAL",
        58);

    const std::vector<Item> &items =
        player.getInventory();

    if (items.empty())
    {
        std::cout << "\nYou place an empty bag on the counter.\n";
        std::cout << "The appraisal machine judges you silently.\n";
    }
    else
    {
        std::cout << "\nThe freight-lift scanner appraises your haul:\n\n";

        for (const Item &item : items)
        {
            std::cout << "  "
                      << std::left
                      << std::setw(34)
                      << item.getName()
                      << "$"
                      << item.getValue()
                      << "\n";
        }
    }

    std::cout << "\n"
              << std::string(58, '-')
              << "\n";

    setTextColor(COLOR_GREEN);

    std::cout << "Payout banked: $"
              << player.getActualInventoryValue()
              << "\n";

    resetTextColor();

    waitForKey();
}

void displayMonsterEncounter(
    const std::string &name,
    const std::string &desc)
{
    clearScreen();

    playSoundEffect(SOUND_ALERT);

    setTextColor(COLOR_RED);

    displayHeader(
        "MONSTER ENCOUNTER",
        42);

    resetTextColor();

    std::cout << "\n>> "
              << name
              << " <<\n\n";

    std::cout << desc
              << "\n";

    std::cout << "\nPrepare for a minigame...\n";

    waitForKey();
}

void displayDayComplete(
    int day,
    const Player &player)
{
    clearScreen();

    playSoundEffect(SOUND_SUCCESS);

    setTextColor(COLOR_GREEN);

    displayHeader(
        "DAY " +
            std::to_string(day) +
            " COMPLETE",
        42);

    resetTextColor();

    std::cout << "\nSketch Malone watches "
              << player.getName()
              << " leave the maze.\n";

    setTextColor(COLOR_YELLOW);

    std::cout << "\"You survived. Payroll is gonna hate that.\"\n";

    resetTextColor();

    std::cout << "\nRest while you can.\n";

    waitForKey();
}

void displayGameWon(
    const Player &player)
{
    clearScreen();

    playSoundEffect(SOUND_SUCCESS);

    setTextColor(COLOR_GREEN);

    displayHeader(
        "YOU ESCAPED",
        42);

    resetTextColor();

    std::cout << "\n"
              << player.getName()
              << "'s debt is paid.\n";

    std::cout << "Sketch leaves you with a Slightly Dangerous LLC business card.\n\n";

    setTextColor(COLOR_YELLOW);

    std::cout << "SKETCH MALONE: \"Call me if you ever destroy another house.\"\n";

    resetTextColor();

    std::cout << "\nFreedom feels... unfamiliar.\n";

    waitForKey();
}

void displayGameOver(
    const Player &player)
{
    clearScreen();

    playSoundEffect(SOUND_HIT);

    setTextColor(COLOR_RED);

    displayHeader(
        "GAME OVER",
        42);

    resetTextColor();

    std::cout << "\nSketch Malone sighs.\n";

    setTextColor(COLOR_YELLOW);

    std::cout << "\""
              << player.getName()
              << " lasted longer than accounting predicted.\"\n";

    resetTextColor();

    std::cout << "\nYour journey ends here.\n";

    waitForKey();
}

void displayMonsterDefeated(
    const std::string &name)
{
    clearScreen();

    playSoundEffect(SOUND_SUCCESS);

    setTextColor(COLOR_GREEN);

    displayHeader(
        "MONSTER DEFEATED",
        42);

    resetTextColor();

    std::cout << "\nYou outplayed the "
              << name
              << ".\n";

    std::cout << "It retreats deeper into the maze...\n";

    std::cout << "\nYou feel a strange sense of relief.\n";

    waitForKey();
}

void displayMonsterHit(
    const std::string &name,
    int heartsLeft)
{
    clearScreen();

    playSoundEffect(SOUND_HIT);

    setTextColor(COLOR_RED);

    displayHeader(
        "YOU WERE HIT",
        42);

    resetTextColor();

    std::cout << "\nThe "
              << name
              << " strikes you!\n";

    std::cout << "You lose 1 heart.\n\n";

    if (heartsLeft <= 1)
        setTextColor(COLOR_RED);
    else
        setTextColor(COLOR_WHITE);

    std::cout << "Hearts remaining: "
              << heartsLeft
              << "\n";

    resetTextColor();

    waitForKey();
}

int displayMenu()
{
    while (true)
    {
        clearScreen();

        setTextColor(COLOR_YELLOW);

        displayHeader(
            "Slightly Dangerous LLC",
            44);

        resetTextColor();

        std::cout << "       Accidents happen. Usually.\n";

        std::cout << "--------------------------------------------\n";

        std::cout << "              [1] New Game\n";
        std::cout << "              [2] How to Play\n";
        std::cout << "              [3] Quit\n";

        std::cout << "--------------------------------------------\n";

        std::cout << "Enter your choice: ";

        char choice =
            getCharChoice("123");

        playSoundEffect(SOUND_MENU);

        if (choice == '1')
        {
            return 1;
        }

        else if (choice == '2')
        {
            displayRules();
        }

        else if (choice == '3')
        {
            return 0;
        }
    }
}

void displayRules()
{
    clearScreen();

    displayHeader(
        "HOW TO PLAY",
        44);

    std::cout << "Use W, A, S, D to move between rooms.\n";

    std::cout << "Each room may contain an item, a monster, or both.\n";

    std::cout << "Items go into an 8-slot inventory instead of becoming money immediately.\n";

    std::cout << "Press I to inspect your loot and read recovered lore.\n";

    std::cout << "Keep, leave, or swap loot when your inventory is full.\n";

    std::cout << "Some strange items hide their value until the exit appraisal.\n";

    std::cout << "Defeat monsters by completing minigames.\n";

    std::cout << "Losing a minigame costs one heart.\n";

    std::cout << "Lose all hearts and the run ends.\n";

    std::cout << "Press M to open a map of only the rooms you have discovered.\n";

    std::cout << "From the map, press N to mark the current room with X, $, !, or ?.\n";

    std::cout << "Each maze contains one physical exit that must be found.\n";

    std::cout << "Press Q in the exit room to turn in carried loot and leave for the day.\n";

    std::cout << "Only returned loot becomes banked money. Leaving below quota ends the run.\n";

    waitForKey();
}
