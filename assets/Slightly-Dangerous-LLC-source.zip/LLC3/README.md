# Slightly Dangerous LLC — Step 3

Step 3 completes the core maze gameplay loop:

`enter -> explore -> map -> encounter -> scavenge -> choose -> find exit -> turn in loot -> meet quota`

## Step 3 systems

- Items enter an 8-slot inventory instead of immediately becoming money.
- The inventory opens with `I` and displays known estimates as well as `$???` items.
- A full inventory forces a keep/leave/replace decision.
- Replaced loot is left in the current room and can be recovered later.
- Money is only banked when carried loot reaches the designated exit scanner.
- Unknown values are revealed during exit appraisal.
- Loot pools vary by day and room type.
- Loot categories include normal valuables, old maze valuables, creature-produced objects, ancient artifacts, and story items.
- Story clues occupy inventory space but permanently unlock optional journal entries.
- The lore journal preserves discoveries even after the physical clue is dropped or turned in.
- Step 2 exploration, notes, physical exits, day themes, and ASCII room art remain intact.

## Controls

- `W/A/S/D` — move through an open doorway
- `M` — open or close the discovered map
- `N` — add or edit the current room's map marker while the map is open
- `I` — open inventory
- `J` — read recovered lore from the inventory screen
- `Q` — use the exit scanner while standing in the designated exit room

## Build on Windows ARM64

Open the VS Code PowerShell terminal inside the `LLC3` folder and run the included build file:

```powershell
.\build.bat
```

The equivalent manual compile command is:

```powershell
clang++ main.cpp player.cpp room.cpp item.cpp monster.cpp maze.cpp minigame.cpp animation.cpp hud.cpp utils.cpp story.cpp -std=c++17 -Wall -Wextra -o LLC3.exe
```

Run the game:

```powershell
.\LLC3.exe
```

## Optional automated tests

Step 2 maze test:

```powershell
clang++ tests/maze_step2_test.cpp room.cpp item.cpp monster.cpp maze.cpp -std=c++17 -Wall -Wextra -I. -o maze_test.exe
.\maze_test.exe
```

Step 3 inventory, loot, lore, and economy test:

```powershell
clang++ tests/step3_test.cpp player.cpp room.cpp item.cpp monster.cpp maze.cpp hud.cpp utils.cpp -std=c++17 -Wall -Wextra -I. -o step3_test.exe
.\step3_test.exe
```

The Step 3 test also checks 750 generated mazes to confirm that an optimal eight-slot haul can meet each day's quota.
