// player.h - header file for the Player class
#ifndef PLAYER_H
#define PLAYER_H

#include "item.h"

#include <string>
#include <vector>

struct LoreRecord
{
    std::string title;
    std::string text;
};

class Player
{
private:
    std::string name; // name chosen by the player at the beginning of the game
    int hearts;       // number of hearts the player currently has
    int money;        // banked money from loot successfully returned to the exit
    int row, col;     // current maze coordinates
    std::vector<Item> inventory;
    std::vector<LoreRecord> loreJournal;

    void recordLoreFromItem(const Item &item);

public:
    static constexpr int INVENTORY_CAPACITY = 8;

    Player();                     // default constructor
    Player(const std::string &n); // constructor used after the player enters a name

    // getters
    std::string getName() const; // returns the player's name
    int getHearts() const;       // returns number of hearts
    int getMoney() const;        // returns amount of money
    int getRow() const;          // returns row coordinate
    int getCol() const;          // returns column coordinate
    const std::vector<Item> &getInventory() const;
    const std::vector<LoreRecord> &getLoreJournal() const;
    int getInventoryCount() const;
    int getKnownInventoryValue() const;
    int getActualInventoryValue() const;
    int getUnknownValueCount() const;
    bool isInventoryFull() const;

    // setters / player state changes
    void setName(const std::string &n); // changes the player's name
    void setPosition(int r, int c);     // sets the player's maze position
    void addMoney(int amount);          // adds or subtracts money
    void loseHeart();                   // removes one heart
    void resetHearts();                 // resets hearts to starting amount

    bool addToInventory(const Item &item);
    Item replaceInventoryItem(int index, const Item &newItem);
    int turnInInventory();

    // movement helper kept for future use
    void move(char direction); // moves player one space in the given direction

    void displayStats() const; // displays basic player information
};

#endif
