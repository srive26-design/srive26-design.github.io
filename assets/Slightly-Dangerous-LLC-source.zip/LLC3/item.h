// item.h - header file for the Item class
#ifndef ITEM_H
#define ITEM_H

#include <string>

// Item categories affect where loot appears and how it is presented.
enum ItemCategory
{
    NORMAL_VALUABLE,
    OLD_MAZE_VALUABLE,
    CREATURE_OBJECT,
    ANCIENT_ARTIFACT,
    STORY_ITEM
};

class Item
{ // Item class declaration
private:
    std::string name; // name of the item
    int value;        // how many credits the item is worth
    bool collected;   // true after the player picks it up
    std::string lore; // lore/description of the item
    ItemCategory category;
    bool valueKnown;          // false hides the price until exit appraisal
    std::string loreTitle;    // journal heading for an optional story clue
    std::string loreEntry;    // permanent journal text discovered by carrying it
public:
    Item(std::string n,
         int v,
         std::string l = "",
         ItemCategory c = NORMAL_VALUABLE,
         bool known = true,
         std::string journalTitle = "",
         std::string journalEntry = "");

    std::string getName() const { return name; }    // get the name of the item
    int getValue() const { return value; }          // get the value of the item
    std::string getLore() const { return lore; }    // get the lore of the item
    ItemCategory getCategory() const { return category; }
    std::string getCategoryName() const;
    bool isValueKnown() const { return valueKnown; }
    bool containsLore() const { return !loreEntry.empty(); }
    std::string getLoreTitle() const { return loreTitle; }
    std::string getLoreEntry() const { return loreEntry; }
    bool isCollected() const { return collected; }  // check if the item has been picked up
    void setCollected(bool c) { collected = c; }    // set the item as collected
};

struct ItemInfo
{                     // struct to hold item information
    std::string name; // name of the item
    int minValue;     // minimum possible value
    int maxValue;     // maximum possivle value
    std::string lore; // visible description
    ItemCategory category;
    bool valueKnown;
    std::string loreTitle;
    std::string loreEntry;
};

// Loot pools are selected by both the current day and room type.
extern const ItemInfo NORMAL_ITEMS[];
extern const int NORMAL_ITEM_COUNT;

extern const ItemInfo OLD_MAZE_ITEMS[];
extern const int OLD_MAZE_ITEM_COUNT;

extern const ItemInfo CREATURE_ITEMS[];
extern const int CREATURE_ITEM_COUNT;

extern const ItemInfo ANCIENT_ITEMS[];
extern const int ANCIENT_ITEM_COUNT;

extern const ItemInfo DAY1_STORY_ITEMS[];
extern const int DAY1_STORY_ITEM_COUNT;

extern const ItemInfo DAY2_STORY_ITEMS[];
extern const int DAY2_STORY_ITEM_COUNT;

extern const ItemInfo DAY3_STORY_ITEMS[];
extern const int DAY3_STORY_ITEM_COUNT;

#endif
