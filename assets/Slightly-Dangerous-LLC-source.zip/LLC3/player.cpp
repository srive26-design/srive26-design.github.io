// player.cpp - implementation file for the Player class
#include "player.h"

#include <cctype>   // toupper
#include <iostream> // cout

Player::Player()
{
    name = "Employee"; // default name in case no custom name has been assigned yet
    hearts = 3;
    money = 0;
    row = 0;
    col = 0;
}

Player::Player(const std::string &n)
{
    name = n;
    hearts = 3;
    money = 0;
    row = 0;
    col = 0;
}

std::string Player::getName() const
{
    return name;
}

int Player::getHearts() const
{
    return hearts;
}

int Player::getMoney() const
{
    return money;
}

int Player::getRow() const
{
    return row;
}

int Player::getCol() const
{
    return col;
}

const std::vector<Item> &Player::getInventory() const
{
    return inventory;
}

const std::vector<LoreRecord> &Player::getLoreJournal() const
{
    return loreJournal;
}

int Player::getInventoryCount() const
{
    return static_cast<int>(inventory.size());
}

int Player::getKnownInventoryValue() const
{
    int total = 0;

    for (const Item &item : inventory)
    {
        if (item.isValueKnown())
            total += item.getValue();
    }

    return total;
}

int Player::getActualInventoryValue() const
{
    int total = 0;

    for (const Item &item : inventory)
        total += item.getValue();

    return total;
}

int Player::getUnknownValueCount() const
{
    int count = 0;

    for (const Item &item : inventory)
    {
        if (!item.isValueKnown())
            count++;
    }

    return count;
}

bool Player::isInventoryFull() const
{
    return getInventoryCount() >= INVENTORY_CAPACITY;
}

void Player::setName(const std::string &n)
{
    name = n;
}

void Player::setPosition(int r, int c)
{
    row = r;
    col = c;
}

void Player::addMoney(int amount)
{
    money += amount;

    if (money < 0) // money should never become negative after Sketch collects a quota
        money = 0;
}

void Player::loseHeart()
{
    if (hearts > 0)
        hearts--;
}

void Player::resetHearts()
{
    hearts = 3;
}

void Player::recordLoreFromItem(const Item &item)
{
    if (!item.containsLore())
        return;

    for (const LoreRecord &entry : loreJournal)
    {
        if (entry.title == item.getLoreTitle())
            return;
    }

    loreJournal.push_back(
        {item.getLoreTitle(), item.getLoreEntry()});
}

bool Player::addToInventory(const Item &item)
{
    if (isInventoryFull())
        return false;

    inventory.push_back(item);
    inventory.back().setCollected(true);

    recordLoreFromItem(item);

    return true;
}

Item Player::replaceInventoryItem(
    int index,
    const Item &newItem)
{
    Item oldItem = inventory[index];

    inventory[index] = newItem;
    inventory[index].setCollected(true);

    recordLoreFromItem(newItem);

    oldItem.setCollected(false);

    return oldItem;
}

int Player::turnInInventory()
{
    int payout = getActualInventoryValue();

    addMoney(payout);
    inventory.clear();

    return payout;
}

void Player::move(char direction)
{
    switch (std::toupper(static_cast<unsigned char>(direction)))
    {
    case 'W':
        row--;
        break;

    case 'S':
        row++;
        break;

    case 'A':
        col--;
        break;

    case 'D':
        col++;
        break;
    }
}

void Player::displayStats() const
{
    std::cout << name
              << " | Hearts: " << hearts
              << " | Banked: $" << money
              << " | Inventory: " << getInventoryCount()
              << "/" << INVENTORY_CAPACITY
              << std::endl;
}
