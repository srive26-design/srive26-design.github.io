// minigame.cpp - minigame functions used during monster encounters
#include "minigame.h"

#include <chrono>  // steady_clock, duration_cast
#include <cstdlib> // rand
#include <iostream>
#include <thread> // sleep_for

void showCountdown(int seconds)
{
    for (int i = seconds; i > 0; i--)
    {
        std::cout << "\rStarting in: "
                  << i
                  << " "
                  << std::flush;

        std::this_thread::sleep_for(
            std::chrono::seconds(1));
    }

    std::cout << "\rGO!            \n";
}

bool vending(const std::string &monsterName)
{
    clearScreen();

    std::cout << "A malfunctioning vending machine flickers violently.\n";

    std::cout << monsterName
              << " stands guard beside it, watching your every move.\n";

    std::cout << "\"Choose correctly,\" it warns.\n\n";

    int correct =
        std::rand() % 3 + 1;

    std::cout << "Three buttons light up:\n";

    std::cout << "1) Cracked Energy Drink\n";

    std::cout << "2) Unlabeled Can\n";

    std::cout << "3) Expired Iced Tea\n\n";

    std::cout << "Only one button is actually connected to anything. Good luck.\n\n";

    std::cout << "Which do you press? (1-3): ";

    int choice =
        getIntInRange(1, 3);

    return choice == correct;
}

bool dodge(const std::string &monsterName)
{
    clearScreen();

    std::cout << monsterName
              << " suddenly charges toward you!\n";

    std::cout << "You have only a split second to move.\n\n";

    char directions[3] =
        {'L', 'C', 'R'};

    // one randomly selected direction avoids the attack
    char safeDirection =
        directions[std::rand() % 3];

    std::cout << "DODGE NOW!\n";

    std::cout << "Choose a direction:\n";

    std::cout << "  (L)eft\n";

    std::cout << "  (C)enter\n";

    std::cout << "  (R)ight\n\n";

    std::cout << "Your move: ";

    char choice =
        getCharChoice("LCR");

    return choice == safeDirection;
}

bool code(const std::string &monsterName)
{
    clearScreen();

    std::cout << monsterName
              << " blocks a locked terminal in the maze.\n";

    std::cout << "\"ENTER VERIFICATION CODE TO PROCEED.\"\n\n";

    std::string verificationCode =
        "CBHJ" +
        std::to_string(
            std::rand() % 900 + 100);

    std::cout << "TYPE THIS CODE EXACTLY: "
              << verificationCode
              << "\n";

    std::cout << "You have 10 seconds after the prompt appears.\n\n";

    showCountdown(3);

    auto start =
        std::chrono::steady_clock::now();

    std::string input =
        getLineInput(
            "Code: ",
            1,
            20);

    auto end =
        std::chrono::steady_clock::now();

    long long elapsed =
        std::chrono::duration_cast<std::chrono::milliseconds>(
            end - start)
            .count();

    if (elapsed > 10000)
    {
        std::cout << "\nToo slow. The terminal flashes red.\n";

        delay(700);

        return false;
    }

    return input == verificationCode;
}

bool company(const std::string &monsterName)
{
    clearScreen();

    std::cout << monsterName
              << " drifts silently in front of you.\n";

    std::cout << "It holds up what appears to be an employee training card.\n\n";

    std::cout << "What is the most professional response to a workplace issue?\n";

    std::cout << "A) Ignore the issue entirely\n";

    std::cout << "B) Address it calmly and responsibly\n";

    std::cout << "C) Scream louder than everyone else\n\n";

    std::cout << "Your answer: ";

    char choice =
        getCharChoice("ABC");

    // unlike the old version, the sensible answer is intentionally correct
    return choice == 'B';
}

bool memorize(const std::string &monsterName)
{
    clearScreen();

    std::cout << "The corridor distorts around "
              << monsterName
              << ".\n";

    std::cout << "Memorize the sequence before it fades. You have 3 seconds.\n\n";

    char symbols[10] =
        {'A', 'B', 'C', 'D', 'E',
         'F', 'Z', 'Y', 'X', 'W'};

    std::string sequence;

    for (int i = 0; i < 6; i++)
    {
        sequence +=
            symbols[std::rand() % 10];
    }

    std::cout << "SEQUENCE: "
              << sequence
              << "\n";

    std::cout << "Get ready...\n";

    std::this_thread::sleep_for(
        std::chrono::seconds(3));

    clearScreen();

    std::string input =
        getLineInput(
            "Enter the sequence: ",
            1,
            20);

    return input == sequence;
}

bool shake(const std::string &monsterName)
{
    clearScreen();

    std::cout << "The hallway goes quiet...\n";

    std::cout << monsterName
              << " steps forward and slowly raises its hand toward you.\n\n";

    std::cout << "What do you do?\n";

    std::cout << "A) Lower your head and bow\n";

    std::cout << "B) Shake its hand confidently\n";

    std::cout << "C) Back away slowly\n\n";

    std::cout << "Your move: ";

    char choice =
        getCharChoice("ABC");

    // this creature expects submission, not friendliness
    if (choice == 'A')
        return true;

    return false;
}