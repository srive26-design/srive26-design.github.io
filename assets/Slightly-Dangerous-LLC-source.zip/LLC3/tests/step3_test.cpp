#include "hud.h"
#include "maze.h"
#include "player.h"

#include <algorithm>
#include <cassert>
#include <cstdlib>
#include <iostream>
#include <sstream>
#include <vector>

static Item makeKnownItem(
    const std::string &name,
    int value)
{
    return Item(
        name,
        value,
        "test item",
        NORMAL_VALUABLE,
        true);
}

static Item makeLoreItem(
    const std::string &name,
    const std::string &title)
{
    return Item(
        name,
        0,
        "test clue",
        STORY_ITEM,
        false,
        title,
        "A permanent journal entry.");
}

static void testInventoryAndEconomy()
{
    Player player("Tester");

    assert(player.getInventoryCount() == 0);
    assert(player.getMoney() == 0);
    assert(player.getKnownInventoryValue() == 0);

    for (int i = 0; i < Player::INVENTORY_CAPACITY; i++)
    {
        assert(player.addToInventory(
            makeKnownItem(
                "Known Item " + std::to_string(i + 1),
                (i + 1) * 10)));
    }

    assert(player.isInventoryFull());
    assert(player.getInventoryCount() == 8);
    assert(player.getKnownInventoryValue() == 360);
    assert(player.getActualInventoryValue() == 360);

    assert(!player.addToInventory(
        makeKnownItem("Ninth Item", 999)));

    Item unknown(
        "Unknown Artifact",
        150,
        "test artifact",
        ANCIENT_ARTIFACT,
        false);

    Item dropped =
        player.replaceInventoryItem(0, unknown);

    assert(dropped.getName() == "Known Item 1");
    assert(!dropped.isCollected());
    assert(player.getInventoryCount() == 8);
    assert(player.getKnownInventoryValue() == 350);
    assert(player.getUnknownValueCount() == 1);
    assert(player.getActualInventoryValue() == 500);

    int payout = player.turnInInventory();

    assert(payout == 500);
    assert(player.getMoney() == 500);
    assert(player.getInventoryCount() == 0);
    assert(player.getActualInventoryValue() == 0);

    player.addMoney(-200);
    assert(player.getMoney() == 300);
}

static void testLoreJournal()
{
    Player player("Archivist");

    Item firstClue =
        makeLoreItem("Document A", "Hidden Agreement");

    Item duplicateClue =
        makeLoreItem("Document B", "Hidden Agreement");

    assert(player.addToInventory(firstClue));
    assert(player.getLoreJournal().size() == 1);

    assert(player.addToInventory(duplicateClue));
    assert(player.getLoreJournal().size() == 1);

    player.turnInInventory();

    // Turning in or dropping the physical clue never erases learned lore.
    assert(player.getLoreJournal().size() == 1);
    assert(player.getLoreJournal()[0].title == "Hidden Agreement");
}

static void testHiddenValuesInDisplays()
{
    Player player("Viewer");

    player.addToInventory(
        makeKnownItem("Visible Watch", 75));

    player.addToInventory(
        Item(
            "Hidden Idol",
            240,
            "test",
            ANCIENT_ARTIFACT,
            false));

    std::ostringstream inventoryOutput;
    std::streambuf *oldOutput =
        std::cout.rdbuf(inventoryOutput.rdbuf());

    displayInventoryScreen(player);

    std::cout.rdbuf(oldOutput);

    assert(inventoryOutput.str().find("Visible Watch") != std::string::npos);
    assert(inventoryOutput.str().find("$75") != std::string::npos);
    assert(inventoryOutput.str().find("Hidden Idol") != std::string::npos);
    assert(inventoryOutput.str().find("$???") != std::string::npos);

    // The real hidden appraisal must not appear on the normal inventory screen.
    assert(inventoryOutput.str().find("$240") == std::string::npos);
}

static void testDayAndRoomLootPools()
{
    std::srand(12345);

    Maze maze(5, 5);

    for (int i = 0; i < 300; i++)
    {
        Item *dayOne =
            maze.generateRandomItem(1, ROOM_OFFICE);

        assert(dayOne->getCategory() == NORMAL_VALUABLE ||
               dayOne->getCategory() == STORY_ITEM);

        delete dayOne;

        Item *dayTwoFungus =
            maze.generateRandomItem(2, ROOM_FUNGUS_GROWTH);

        assert(dayTwoFungus->getCategory() == CREATURE_OBJECT ||
               dayTwoFungus->getCategory() == OLD_MAZE_VALUABLE ||
               dayTwoFungus->getCategory() == STORY_ITEM);

        delete dayTwoFungus;

        Item *dayThreeRitual =
            maze.generateRandomItem(3, ROOM_RITUAL_CHAMBER);

        assert(dayThreeRitual->getCategory() == ANCIENT_ARTIFACT ||
               dayThreeRitual->getCategory() == CREATURE_OBJECT ||
               dayThreeRitual->getCategory() == STORY_ITEM);

        delete dayThreeRitual;
    }
}

static int bestEightItemValue(Maze &maze)
{
    std::vector<int> values;

    for (int r = 0; r < maze.getRows(); r++)
    {
        for (int c = 0; c < maze.getCols(); c++)
        {
            Item *item = maze.getRoom(r, c).getItem();

            if (item)
                values.push_back(item->getValue());
        }
    }

    std::sort(values.begin(), values.end(), std::greater<int>());

    int total = 0;
    int count =
        std::min(
            static_cast<int>(values.size()),
            Player::INVENTORY_CAPACITY);

    for (int i = 0; i < count; i++)
        total += values[i];

    return total;
}

static void testQuotaBalance()
{
    const int quotas[3] = {50, 200, 600};

    // An exhaustive player who chooses the best eight finds enough value in
    // every tested maze. This checks that capacity does not make a day unwinnable.
    for (int day = 1; day <= 3; day++)
    {
        for (int seed = 1; seed <= 250; seed++)
        {
            std::srand((day * 10000) + seed);

            Maze maze(5, 5);
            maze.generateMaze(day);

            assert(bestEightItemValue(maze) >= quotas[day - 1]);
        }
    }
}

int main()
{
    testInventoryAndEconomy();
    testLoreJournal();
    testHiddenValuesInDisplays();
    testDayAndRoomLootPools();
    testQuotaBalance();

    std::cout << "All Step 3 inventory, economy, loot, and lore tests passed.\n";
    return 0;
}
