#include "maze.h"

#include <cassert>
#include <cstdlib>
#include <iostream>
#include <queue>
#include <sstream>
#include <utility>
#include <vector>

static bool typeAllowedOnDay(RoomType type, int day)
{
    if (type == ROOM_EXIT)
        return true;

    if (day == 1)
    {
        return type == ROOM_STORAGE ||
               type == ROOM_MAINTENANCE ||
               type == ROOM_OFFICE ||
               type == ROOM_WASTE_PROCESSING ||
               type == ROOM_HALLWAY;
    }

    if (day == 2)
    {
        return type == ROOM_LABORATORY ||
               type == ROOM_TESTING ||
               type == ROOM_FUNGUS_GROWTH ||
               type == ROOM_WASTE_PROCESSING ||
               type == ROOM_MAINTENANCE ||
               type == ROOM_HALLWAY;
    }

    return type == ROOM_RITUAL_CHAMBER ||
           type == ROOM_LABORATORY ||
           type == ROOM_FUNGUS_GROWTH ||
           type == ROOM_TESTING ||
           type == ROOM_WASTE_PROCESSING ||
           type == ROOM_MAINTENANCE ||
           type == ROOM_HALLWAY;
}

static int countReachableRooms(Maze &maze, int startR, int startC)
{
    std::vector<std::vector<bool>> seen(
        maze.getRows(),
        std::vector<bool>(maze.getCols(), false));

    std::queue<std::pair<int, int>> pending;
    pending.push({startR, startC});
    seen[startR][startC] = true;

    int count = 0;

    while (!pending.empty())
    {
        int r = pending.front().first;
        int c = pending.front().second;
        pending.pop();
        count++;

        const Room &room = maze.getRoom(r, c);

        if (room.isOpenTop())
        {
            assert(r > 0);
            assert(maze.getRoom(r - 1, c).isOpenBottom());
            if (!seen[r - 1][c])
            {
                seen[r - 1][c] = true;
                pending.push({r - 1, c});
            }
        }

        if (room.isOpenBottom())
        {
            assert(r < maze.getRows() - 1);
            assert(maze.getRoom(r + 1, c).isOpenTop());
            if (!seen[r + 1][c])
            {
                seen[r + 1][c] = true;
                pending.push({r + 1, c});
            }
        }

        if (room.isOpenLeft())
        {
            assert(c > 0);
            assert(maze.getRoom(r, c - 1).isOpenRight());
            if (!seen[r][c - 1])
            {
                seen[r][c - 1] = true;
                pending.push({r, c - 1});
            }
        }

        if (room.isOpenRight())
        {
            assert(c < maze.getCols() - 1);
            assert(maze.getRoom(r, c + 1).isOpenLeft());
            if (!seen[r][c + 1])
            {
                seen[r][c + 1] = true;
                pending.push({r, c + 1});
            }
        }
    }

    return count;
}

int main()
{
    for (int day = 1; day <= 3; day++)
    {
        std::srand(400 + day);

        Maze maze(5, 5);
        maze.generateMaze(day);

        int exitCount = 0;
        int visitedCount = 0;

        for (int r = 0; r < maze.getRows(); r++)
        {
            for (int c = 0; c < maze.getCols(); c++)
            {
                const Room &room = maze.getRoom(r, c);

                if (room.isVisited())
                    visitedCount++;

                assert(typeAllowedOnDay(room.getType(), day));

                if (room.isExit())
                {
                    exitCount++;
                    assert(!(r == 2 && c == 2));
                    assert(room.getType() == ROOM_EXIT);
                    assert(room.getItem() == nullptr);
                    assert(room.getMonster() == nullptr);
                }
            }
        }

        assert(exitCount == 1);
        assert(visitedCount == 0);
        assert(maze.getRoom(2, 2).getItem() == nullptr);
        assert(maze.getRoom(2, 2).getMonster() == nullptr);
        assert(countReachableRooms(maze, 2, 2) == 25);

        Room &start = maze.getRoom(2, 2);
        start.setVisited(true);
        start.setPlayerNote("!");
        assert(start.getPlayerNote() == "!");

        std::ostringstream mapOutput;
        std::streambuf *oldOutput = std::cout.rdbuf(mapOutput.rdbuf());
        maze.displayMap(2, 2);
        std::cout.rdbuf(oldOutput);

        assert(mapOutput.str().find("@") != std::string::npos);
        assert(mapOutput.str().find("?") != std::string::npos);

        std::ostringstream roomOutput;
        oldOutput = std::cout.rdbuf(roomOutput.rdbuf());
        maze.displayRoom(2, 2, true);
        maze.displayRoom(2, 2, false);
        std::cout.rdbuf(oldOutput);

        assert(roomOutput.str().find("UNMAPPED ROOM") != std::string::npos);
        assert(roomOutput.str().find("PREVIOUSLY VISITED") != std::string::npos);
        assert(roomOutput.str().find("Map note: [!]") != std::string::npos);
    }

    std::cout << "All Step 2 maze tests passed.\n";
    return 0;
}
