// room.h - header file for the Room class
#ifndef ROOM_H
#define ROOM_H

#include "item.h"
#include "monster.h"
#include <string>

// A room's type controls its title, atmosphere, visual details,
// and small changes to item / monster spawn chances.
enum RoomType
{
    ROOM_STORAGE,
    ROOM_MAINTENANCE,
    ROOM_LABORATORY,
    ROOM_OFFICE,
    ROOM_WASTE_PROCESSING,
    ROOM_RITUAL_CHAMBER,
    ROOM_FUNGUS_GROWTH,
    ROOM_TESTING,
    ROOM_HALLWAY,
    ROOM_EXIT
};

class Room
{ // Room class declaration
private:
    bool openTop, openBottom, openLeft, openRight; // bool value for which sides have hallways
    bool visited;                                  // true after the player enters this room
    bool exitRoom;                                 // true for the maze's designated exit
    RoomType type;                                 // visual / gameplay identity of this room
    std::string playerNote;                        // optional one-character map annotation
    Item *item;                                    // pointer to the item in the room (if any) nullptr if none
    Monster *monster;                              // pointer to the monster in the room

public:
    Room(); // constructor

    // getter functions for each side of the room
    bool isOpenTop() const; // returns true if there's a hallway on (top/bottom/left/right) of the room
    bool isOpenBottom() const;
    bool isOpenLeft() const;
    bool isOpenRight() const;

    // setter functions for each side of the room
    void setOpenTop(bool value); // to mark a hallway (top/bottom/left/right) as open or closed
    void setOpenBottom(bool value);
    void setOpenLeft(bool value);
    void setOpenRight(bool value);

    bool isVisited() const;      // checks if the room has been visited
    void setVisited(bool value); // sets the visited status of the room

    bool isExit() const;      // checks whether this room contains the designated exit
    void setExit(bool value); // marks or clears the room as the designated exit

    RoomType getType() const;       // returns the room's assigned type
    void setType(RoomType newType); // assigns the room's type

    std::string getPlayerNote() const;              // returns the player's map marker
    void setPlayerNote(const std::string &newNote); // stores or clears a map marker

    Item *getItem() const;                // gets the item in the room
    void setItem(Item *newItem);          // sets the item in the room to new item
    Monster *getMonster() const;          // gets the monster in the room
    void setMonster(Monster *newMonster); // sets the monster in the room to new monster
};

#endif
