@echo off
clang++ main.cpp player.cpp room.cpp item.cpp monster.cpp maze.cpp minigame.cpp animation.cpp hud.cpp utils.cpp story.cpp -std=c++17 -Wall -Wextra -o LLC3.exe

if errorlevel 1 (
    echo.
    echo Build failed.
    exit /b 1
)

echo.
echo Build successful: LLC3.exe
