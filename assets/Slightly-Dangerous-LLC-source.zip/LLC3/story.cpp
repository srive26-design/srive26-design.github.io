// story.cpp - implementation of story and day transition screens
#include "story.h"
#include "utils.h"

#include <iostream>

// helper used only in this file to separate story screens
static void storyContinue()
{
    waitForKey();

    clearScreen();
}

std::string runOpeningSequence()
{
    clearScreen();

    setTextColor(COLOR_GRAY);

    displayHeader(
        "ROCHESTER COUNTY - 11:47 PM",
        46);

    resetTextColor();

    std::cout << "Rain hammers against the windshield.\n\n";

    std::cout << "You are driving down an almost completely dark road,\n";

    std::cout << "trying to make it to your sister Vanessa's place before midnight.\n\n";

    std::cout << "The GPS says you are close.\n";

    std::cout << "The road says you are probably going to die.\n";

    storyContinue();

    setTextColor(COLOR_CYAN);

    std::cout << "...tap... tap... tap...\n";

    resetTextColor();

    delay(450);

    std::cout << "The windshield wipers drag across the glass.\n";

    delay(500);

    std::cout << "Something moves at the edge of your headlights.\n\n";

    delay(700);

    setTextColor(COLOR_WHITE);

    std::cout << "                /\\_/\\\n";
    std::cout << "               / o o  \\\n";
    std::cout << "              (    ^   )\n";
    std::cout << "               \\  -- /\n";
    std::cout << "                -----\n\n";

    resetTextColor();

    setTextColor(COLOR_RED);

    std::cout << "DEER.\n";

    resetTextColor();

    playSoundEffect(SOUND_ALERT);

    delay(350);

    std::cout << "You jerk the wheel.\n";

    delay(300);

    std::cout << "The tires lose the road.\n";

    delay(300);

    playSoundEffect(SOUND_CRASH);

    setTextColor(COLOR_RED);

    std::cout << "\nCRASH.\n";

    std::cout << "CRUNCH.\n";

    std::cout << "A SECOND, MUCH MORE EXPENSIVE CRUNCH.\n";

    resetTextColor();

    delay(500);

    std::cout << "Then something behind the car explodes.\n";

    storyContinue();

    displayHeader(
        "A VERY BAD PARKING DECISION",
        46);

    std::cout << "You crawl out of your car.\n\n";

    std::cout << "Your front bumper is inside a very nice parked car.\n";

    std::cout << "The very nice parked car is now inside a house.\n";

    std::cout << "The house is on fire.\n\n";

    std::cout << "A man steps out of the smoke wearing sunglasses at midnight.\n";

    std::cout << "He is holding a rifle.\n\n";

    setTextColor(COLOR_YELLOW);

    std::cout << "SKETCH MALONE: \"That was my car.\"\n";

    std::cout << "SKETCH MALONE: \"And, unless I am mistaken, that was also my house.\"\n";

    resetTextColor();

    storyContinue();

    setTextColor(COLOR_YELLOW);

    std::cout << "SKETCH MALONE: \"You got two ways to pay me back.\"\n\n";

    resetTextColor();

    std::cout << "He raises the rifle slightly.\n\n";

    setTextColor(COLOR_YELLOW);

    std::cout << "SKETCH MALONE: \"One is extremely short-term employment.\"\n";

    std::cout << "SKETCH MALONE: \"The other is extremely short-term everything.\"\n\n";

    resetTextColor();

    std::cout << "Work for Slightly Dangerous LLC? (Y/N): ";

    char answer =
        getCharChoice("YN");

    if (answer == 'N')
    {
        clearScreen();

        playSoundEffect(SOUND_HIT);

        setTextColor(COLOR_RED);

        displayHeader(
            "GAME OVER",
            40);

        std::cout << "You declined a competitive employment opportunity.\n\n";

        resetTextColor();

        std::cout << "Sketch Malone respects your confidence.\n";

        std::cout << "He does not respect it for very long.\n";

        waitForKey();

        return "";
    }

    clearScreen();

    displayHeader(
        "SLIGHTLY DANGEROUS LLC",
        46);

    std::cout << "Sketch lowers the rifle.\n\n";

    setTextColor(COLOR_YELLOW);

    std::cout << "SKETCH MALONE: \"Smart. HR loves initiative.\"\n";

    std::cout << "SKETCH MALONE: \"You go into my maze, carry out valuables,\"\n";

    std::cout << "SKETCH MALONE: \"and I subtract the money from what you owe me.\"\n\n";

    std::cout << "SKETCH MALONE: \"Nothing gets paid until it reaches my exit scanner.\"\n\n";

    std::cout << "SKETCH MALONE: \"Now. Name?\"\n\n";

    resetTextColor();

    std::string playerName =
        getLineInput(
            "Enter your name: ",
            1,
            30);

    playSoundEffect(SOUND_MENU);

    std::cout << "\nSketch writes \""
              << playerName
              << "\" on a clipboard.\n";

    std::cout << "The form is already signed at the bottom.\n";

    std::cout << "You do not remember signing it.\n\n";

    setTextColor(COLOR_YELLOW);

    std::cout << "SKETCH MALONE: \"Welcome aboard. Try not to breathe too deep in there.\"\n";

    resetTextColor();

    waitForKey();

    return playerName;
}

void displayShiftIntro(
    const Player &player,
    int day,
    const std::string &shiftName,
    const std::string &atmosphere,
    int quota)
{
    clearScreen();

    displayHeader(
        "SLIGHTLY DANGEROUS LLC - SHIFT BRIEFING",
        52);

    setTextColor(COLOR_CYAN);

    std::cout << "Employee: "
              << player.getName()
              << "\n";

    resetTextColor();

    std::cout << "Day: "
              << day
              << "\n";

    std::cout << "Assignment: "
              << shiftName
              << "\n";

    setTextColor(COLOR_GREEN);

    std::cout << "Required quota: $"
              << quota
              << "\n";

    resetTextColor();

    std::cout << "\n"
              << atmosphere
              << "\n\n";

    setTextColor(COLOR_YELLOW);

    std::cout << "SKETCH MALONE: \"Bring me enough to cover the quota and you get to come back tomorrow.\"\n";

    std::cout << "SKETCH MALONE: \"Your bag has eight slots. Pick what deserves one.\"\n";

    resetTextColor();

    waitForKey();
}
