// item.cpp - implementation file for the Item class

#include "item.h" // include header file

/* Constructor for Item object */
Item::Item(std::string n,
           int v,
           std::string l,
           ItemCategory c,
           bool known,
           std::string journalTitle,
           std::string journalEntry)
{
    name = n;          // assign item name
    value = v;         // assign item value
    lore = l;          // assign item description
    category = c;
    valueKnown = known;
    loreTitle = journalTitle;
    loreEntry = journalEntry;
    collected = false; // item starts as not collected
}

std::string Item::getCategoryName() const
{
    switch (category)
    {
    case NORMAL_VALUABLE:
        return "Normal Valuable";
    case OLD_MAZE_VALUABLE:
        return "Old Maze Valuable";
    case CREATURE_OBJECT:
        return "Creature-Produced Object";
    case ANCIENT_ARTIFACT:
        return "Ancient Artifact";
    case STORY_ITEM:
        return "Story Item";
    default:
        return "Unknown";
    }
}

const ItemInfo NORMAL_ITEMS[] = {
    {"Cracked iPhone", 24, 40, "The lock screen has 47 missed calls from MOM.", NORMAL_VALUABLE, true, "", ""},
    {"Employee Wallet", 14, 30, "No cash. Plenty of expired cafeteria coupons.", NORMAL_VALUABLE, true, "", ""},
    {"Gold Ring", 70, 105, "A wedding date is engraved inside.", NORMAL_VALUABLE, true, "", ""},
    {"Noise-Canceling Headphones", 28, 55, "One side still plays hold music.", NORMAL_VALUABLE, true, "", ""},
    {"Designer Sunglasses", 20, 48, "Impractical underground. Very on-brand for Sketch.", NORMAL_VALUABLE, true, "", ""},
    {"Silver Watch", 45, 85, "It runs seven minutes slow and one year backward.", NORMAL_VALUABLE, true, "", ""},
    {"Overloaded Battery Pack", 35, 75, "It hums even though nothing is connected.", NORMAL_VALUABLE, true, "", ""}};
const int NORMAL_ITEM_COUNT = 7;

const ItemInfo OLD_MAZE_ITEMS[] = {
    {"Gold Pocket Watch", 125, 185, "The initials belong to a trial candidate from 1987.", OLD_MAZE_VALUABLE, true, "", ""},
    {"Tarnished Locket", 48, 92, "The tiny portrait inside has been deliberately scratched out.", OLD_MAZE_VALUABLE, true, "", ""},
    {"Candidate's Compass", 35, 70, "It points toward the nearest wall instead of north.", OLD_MAZE_VALUABLE, true, "", ""},
    {"Sealed Emergency Rations", 18, 42, "The package says PROPERTY OF APPLICANT 12.", OLD_MAZE_VALUABLE, true, "", ""},
    {"Rusted Key", 4, 9, "A triangle has been filed into its bow.", OLD_MAZE_VALUABLE, false, "", ""}};
const int OLD_MAZE_ITEM_COUNT = 5;

const ItemInfo CREATURE_ITEMS[] = {
    {"Molted Scale", 55, 110, "Green-black, warm, and much too large for a normal reptile.", CREATURE_OBJECT, false, "", ""},
    {"Pulsing Fungus Gland", 40, 95, "It tightens when you say the company name.", CREATURE_OBJECT, false, "", ""},
    {"Calcified Egg", 105, 175, "Something taps back when you knock on it.", CREATURE_OBJECT, false, "", ""},
    {"Crystallized Waste", 32, 78, "Gross. Sparkly, but gross.", CREATURE_OBJECT, false, "", ""},
    {"Preserved Third Eyelid", 70, 130, "It keeps trying to blink.", CREATURE_OBJECT, false, "", ""}};
const int CREATURE_ITEM_COUNT = 5;

const ItemInfo ANCIENT_ITEMS[] = {
    {"Black Glass Idol", 210, 340, "Its reflection smiles a moment after you do.", ANCIENT_ARTIFACT, false, "", ""},
    {"Engraved Sun Coin", 145, 235, "The date predates the calendar printed on it.", ANCIENT_ARTIFACT, false, "", ""},
    {"Triangular Seal", 180, 295, "Half eye, half reptile pupil, entirely unsettling.", ANCIENT_ARTIFACT, false, "", ""},
    {"Bone Circuit", 165, 270, "Copper paths were grown through the bone rather than carved.", ANCIENT_ARTIFACT, false, "", ""},
    {"Ceremonial Lens", 195, 315, "Through it, the company logo has a second hidden layer.", ANCIENT_ARTIFACT, false, "", ""}};
const int ANCIENT_ITEM_COUNT = 5;

const ItemInfo DAY1_STORY_ITEMS[] = {
    {"Employee Badge: V. Malone", 0, 0, "Clearance level: INTERNAL REVIEW. The photo has been removed.", STORY_ITEM, false,
     "A Malone in Internal Review",
     "A badge issued to V. Malone grants access far above ordinary employees. The issue date is six months in the future."},
    {"Candidate 04 Damage Waiver", 0, 0, "Most of the legal text has been blacked out after signing.", STORY_ITEM, false,
     "The Trials Came First",
     "Candidate 04 signed a maze injury waiver in 1991. Slightly Dangerous LLC was not incorporated until 2003."},
    {"Half-Burned Family Photo", 0, 0, "Sketch stands beside a woman and a teenage girl. Nobody is smiling.", STORY_ITEM, false,
     "Sketch's Family",
     "The back reads: 'Before the treatment. Before she found the lower door.' The woman's face is burned away."},
    {"Symbol-Etched Bolt", 0, 0, "It looks worthless until the rust flakes off the eye-shaped mark.", STORY_ITEM, false,
     "The Mark Under the Rust",
     "The bolt carries a split eye-and-scale symbol. The same shape is faintly hidden beneath the modern company logo."}};
const int DAY1_STORY_ITEM_COUNT = 4;

const ItemInfo DAY2_STORY_ITEMS[] = {
    {"Control Agreement Fragment", 0, 0, "Only one clause survived the mold.", STORY_ITEM, false,
     "The 50/50 Agreement",
     "Facility control is divided equally between the Lineage Board and the Illuminated Partners. Neither faction may open the original chamber alone."},
    {"Applicant 12 Audio Tape", 0, 0, "A handwritten warning says DO NOT PLAY NEAR FUNGUS.", STORY_ITEM, false,
     "An Earlier Candidate",
     "Applicant 12 says the creatures were once employees and faction members. Gas leaks and fungal exposure changed them after they went rogue."},
    {"Mutation Report 7B", 0, 0, "The final page was replaced with a company pizza coupon.", STORY_ITEM, false,
     "The Mutations Were Observed",
     "The report tracks scale growth, light sensitivity, and shared dreams. Management marked the results 'acceptable workplace adaptation.'"}};
const int DAY2_STORY_ITEM_COUNT = 3;

const ItemInfo DAY3_STORY_ITEMS[] = {
    {"Lineage Ledger", 0, 0, "The family tree branches into names still printed on company doors.", STORY_ITEM, false,
     "The Lizard Lineage",
     "Generations of the Lineage Board guarded the facility before the company existed. Sketch's name appears beside the word 'inheritor.'"},
    {"Illuminated Council Seal", 0, 0, "The eye symbol is split cleanly down the center.", STORY_ITEM, false,
     "The Other Half",
     "The Illuminated Partners funded the modern facility but never controlled the chamber. Their rogue members tried to force it open."},
    {"Field Notes Signed 'V'", 0, 0, "The handwriting looks painfully familiar, but several pages are missing.", STORY_ITEM, false,
     "Vanessa?",
     "Someone signed V mapped a route below the original facility. The last line reads: 'Sketch knows what happened to his wife. He is buying time.'"}};
const int DAY3_STORY_ITEM_COUNT = 3;
