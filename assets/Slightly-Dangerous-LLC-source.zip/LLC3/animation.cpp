// animation.cpp - implementation of hallway walking "animation"
#include "animation.h"

#include <algorithm> // max, min
#include <iostream>
#include <string>
#include <vector>

void animatePlayerWalk(char dir)
{
    const int steps = 12;   // number of animation frames
    const int delayMs = 40; // milliseconds between frames

    int row = 5;

    int col = 14;

    std::vector<std::string> vert = {
        "    :|        |:",
        "    :|        |:",
        "    :|        |:",
        "    :|        |:",
        "    :|        |:",
        "    :|        |:",
        "    :|        |:",
        "    :|        |:",
        "    :|        |:",
        "    :|        |:"};

    std::vector<std::string> horz = {
        "============================",
        "                            ",
        "                            ",
        "============================"};

    for (int i = 0; i < steps; i++)
    {
        clearScreen();

        if (dir == 'L')
            col--;

        if (dir == 'R')
            col++;

        if (dir == 'U')
            row--;

        if (dir == 'D')
            row++;

        // keep the animated player inside the hallway drawing
        col =
            std::max(
                1,
                std::min(col, 27));

        row =
            std::max(
                1,
                std::min(row, 8));

        if (dir == 'U' ||
            dir == 'D')
        {
            for (auto &line : vert)
            {
                line =
                    "    :|        |:";
            }

            if (row >= 0 &&
                row < static_cast<int>(vert.size()) &&
                10 < static_cast<int>(vert[row].size()))
            {
                vert[row][10] = 'P';
            }

            for (const auto &line : vert)
            {
                std::cout << line
                          << "\n";
            }
        }
        else
        {
            horz[0] =
                "============================";

            horz[3] =
                "============================";

            horz[1] =
                "                            ";

            horz[2] =
                "                            ";

            if (col >= 0 &&
                col < static_cast<int>(horz[2].size()))
            {
                horz[2][col] = 'P';
            }

            for (const auto &line : horz)
            {
                std::cout << line
                          << "\n";
            }
        }

        delay(delayMs);
    }
}