// story.h - story and day transition screens
#ifndef STORY_H
#define STORY_H

#include "player.h"

#include <string>

// plays opening story and returns the player's chosen name
std::string runOpeningSequence();

// introduces the current work day
void displayShiftIntro(
    const Player &player,
    int day,
    const std::string &shiftName,
    const std::string &atmosphere,
    int quota);

#endif